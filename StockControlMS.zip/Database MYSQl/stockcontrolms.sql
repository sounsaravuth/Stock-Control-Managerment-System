-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2021 at 01:50 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockcontrolms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `categoryid` varchar(255) NOT NULL,
  `categoryname` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`categoryid`, `categoryname`) VALUES
('category001', 'Monitor'),
('category002', 'Mouse'),
('category003', 'Ram'),
('category004', 'CasePC'),
('category005', 'Mouse Pad'),
('category006', 'CPU'),
('category007', 'Power Supplier'),
('category008', 'USB'),
('category009', 'Network Cable'),
('category10', 'Gamming Chair'),
('category11', 'Adapter Computer Labtop'),
('category12', 'VGA'),
('category13', 'MainBoard Computer');

-- --------------------------------------------------------

--
-- Table structure for table `tbldelivery`
--

CREATE TABLE `tbldelivery` (
  `deliveryid` varchar(255) NOT NULL,
  `deliveryno` varchar(255) DEFAULT NULL,
  `deliverydate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbldelivery`
--

INSERT INTO `tbldelivery` (`deliveryid`, `deliveryno`, `deliverydate`) VALUES
('D01', '001', '2021-11-11'),
('D02', '002', '2021-11-11'),
('D03', '003', '2021-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `tblinvoice`
--

CREATE TABLE `tblinvoice` (
  `Invoiceid` varchar(255) NOT NULL,
  `invoicedate` date DEFAULT NULL,
  `ponumber` varchar(255) DEFAULT NULL,
  `poiddate` date DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblinvoice`
--

INSERT INTO `tblinvoice` (`Invoiceid`, `invoicedate`, `ponumber`, `poiddate`, `price`, `supplierid`) VALUES
('inovice001', '2021-11-27', 'P-000-1', '2021-11-22', '5.00', 'Supplier01'),
('inovice002', '2021-11-28', 'P-000-2', '2021-11-28', '200.00', 'Supplier02'),
('Invoice003', '2021-11-28', 'P-000-3', '2021-11-28', '300.00', 'Supplier02');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `productid` varchar(255) NOT NULL,
  `productname` varchar(255) DEFAULT NULL,
  `categoryid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`productid`, `productname`, `categoryid`) VALUES
('pro001', 'Ram DDR4 8GB', 'category003'),
('pro002', 'Ram DDR4 16GB', 'category003'),
('pro003', 'CPU Core I7', 'category006'),
('pro004', 'USB 8GB', 'category008'),
('pro005', 'USB 16GB', 'category008'),
('pro006', 'USB 32GB', 'category008'),
('pro007', 'VGA 1080 TI', 'category12'),
('pro008', 'VGA 1060 TI', 'category12'),
('pro009', 'VGA 1050 TI', 'category12'),
('pro10', 'Monitor 160 HZ Asus', 'category001'),
('pro11', 'ASUS VG279Q 144hz IPS', 'category001'),
('pro12', 'Monitor ROG STRIX XG27VQ 144hz', 'category001'),
('pro13', 'Razer Iskur - Black / Green', 'category10'),
('pro14', 'Razer  Case01', 'category004');

-- --------------------------------------------------------

--
-- Table structure for table `tblpurchaseorder`
--

CREATE TABLE `tblpurchaseorder` (
  `poid` varchar(255) NOT NULL,
  `ponumber` varchar(255) DEFAULT NULL,
  `podate` date DEFAULT NULL,
  `povalue` decimal(10,0) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblpurchaseorder`
--

INSERT INTO `tblpurchaseorder` (`poid`, `ponumber`, `podate`, `povalue`, `supplierid`) VALUES
('Purchase001', 'P-000-1', '2021-11-22', '5', 'Supplier01'),
('Purchase002', 'P-000-2', '2021-11-28', '200', 'Supplier02'),
('Purchase003', 'P-000-3', '2021-11-28', '300', 'Supplier02');

-- --------------------------------------------------------

--
-- Table structure for table `tblquote`
--

CREATE TABLE `tblquote` (
  `quoteid` varchar(255) NOT NULL,
  `quoteno` varchar(255) DEFAULT NULL,
  `quotevalue` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblquote`
--

INSERT INTO `tblquote` (`quoteid`, `quoteno`, `quotevalue`, `supplierid`) VALUES
('quote001', '001', '2', 'Supplier01'),
('quote002', '002', '3', 'Supplier02'),
('quote003', '003', '4', 'Supplier03');

-- --------------------------------------------------------

--
-- Table structure for table `tblstaff`
--

CREATE TABLE `tblstaff` (
  `staffid` varchar(255) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pob` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblstaff`
--

INSERT INTO `tblstaff` (`staffid`, `fullname`, `gender`, `dob`, `pob`, `tel`, `address`, `email`, `role`, `salary`, `username`, `password`) VALUES
('User001', 'Sounsaravuth', 'Male', '2021-11-15', 'Kompong Channg', '011412625', 'Poipet', 'sounsaravuth3@gmail.com', 'Admin', '100.00', 'saravuth', '1122'),
('User002', 'Somsofiya', 'Female', '2021-11-15', 'SiemReap', '09680987455', 'SiemReap City', 'sofiyasom@gmail.com', 'User', '120.00', 'fiya', '1122'),
('User003', 'KongChhant', 'Male', '2021-11-15', 'SiemReap', '098246246724', 'wat bo', 'kongchhat@gamil.com', 'User', '123.00', 'chhhat', '12345678'),
('User004', 'Ai Audom', 'Male', '2021-11-15', 'SiemReap', '01245332424', 'wat bo', 'audomai@gamil.com', 'User', '123.00', 'audom', '123'),
('User005', 'Chandara', 'Male', '2021-11-28', 'SiemReap', '09877636131313', 'SiemReap City', 'darachan1122@gmail.com', 'User', '200.00', 'Dara', '2233'),
('User006', 'Zhong LiLI', 'Female', '2021-12-07', 'SiemReap', '068908744', 'SiemReap City', 'LiLiZhong1122@gmail.com', 'Admin', '300.00', 'Zhonglili', '2233');

-- --------------------------------------------------------

--
-- Table structure for table `tblstockin`
--

CREATE TABLE `tblstockin` (
  `stockinid` varchar(255) NOT NULL,
  `Datein` date DEFAULT NULL,
  `quantityin` int(255) DEFAULT NULL,
  `unitcost` decimal(10,2) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `productid` varchar(255) DEFAULT NULL,
  `deliveryid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblstockin`
--

INSERT INTO `tblstockin` (`stockinid`, `Datein`, `quantityin`, `unitcost`, `supplierid`, `productid`, `deliveryid`) VALUES
('stock01', '2021-11-28', 3, '5.00', 'Supplier01', 'pro001', 'D01'),
('stock02', '2021-11-28', 6, '35.00', 'Supplier02', 'pro002', 'D02'),
('stock03', '2021-11-28', 7, '40.00', 'Supplier03', 'pro002', 'D01'),
('stock04', '2021-11-28', 8, '250.00', 'Supplier01', 'pro003', 'D01'),
('stock05', '2021-11-28', 8, '16.00', 'Supplier01', 'pro004', 'D01'),
('stock06', '2021-11-28', 5, '32.00', 'Supplier04', 'pro005', 'D01'),
('stock07', '2021-11-28', 5, '64.00', 'Supplier04', 'pro006', 'D01'),
('stock08', '2021-11-28', 10, '300.00', 'Supplier04', 'pro007', 'D02'),
('stock09', '2021-11-28', 11, '400.00', 'Supplier03', 'pro008', 'D02'),
('stock10', '2021-11-28', 20, '400.00', 'Supplier02', 'pro009', 'D01'),
('stock11', '2021-11-28', 9, '534.00', 'Supplier02', 'pro10', 'D01'),
('stock12', '2021-11-28', 2, '200.00', 'Supplier01', 'pro13', 'D02');

-- --------------------------------------------------------

--
-- Table structure for table `tblstockout`
--

CREATE TABLE `tblstockout` (
  `stockoutid` varchar(255) NOT NULL,
  `dateout` date DEFAULT NULL,
  `quantityout` int(255) DEFAULT NULL,
  `stockinid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblstockout`
--

INSERT INTO `tblstockout` (`stockoutid`, `dateout`, `quantityout`, `stockinid`) VALUES
('stockout01', '2021-11-28', 2, 'stock01'),
('stockout02', '2021-11-28', 2, 'stock12');

--
-- Triggers `tblstockout`
--
DELIMITER $$
CREATE TRIGGER `Try_cutstockin` AFTER INSERT ON `tblstockout` FOR EACH ROW BEGIN
UPDATE tblstockin set tblstockin.quantityin = tblstockin.quantityin - new.quantityout where tblstockin.stockinid = new.stockinid;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Try_returnstockin` AFTER DELETE ON `tblstockout` FOR EACH ROW BEGIN
UPDATE tblstockin set tblstockin.quantityin = tblstockin.quantityin + old.quantityout where tblstockin.stockinid = old.stockinid;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblsupplier`
--

CREATE TABLE `tblsupplier` (
  `supplierid` varchar(255) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblsupplier`
--

INSERT INTO `tblsupplier` (`supplierid`, `suppliername`, `tel`, `address`, `email`) VALUES
('Supplier01', 'NTC', '01234332211', 'Poipet City', 'ntccomputer@gamil.com'),
('Supplier02', 'Blue IT', '01234332211', 'Poipet City', 'blueitcomputer@gamil.com'),
('Supplier03', 'PTC', '09689753442', 'SiemReap City', 'ptccomputer@gamil.com'),
('Supplier04', 'khmer computer', '08928292812', 'SiemReap City', 'khmercomputer@gamil.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`categoryid`);

--
-- Indexes for table `tbldelivery`
--
ALTER TABLE `tbldelivery`
  ADD PRIMARY KEY (`deliveryid`);

--
-- Indexes for table `tblinvoice`
--
ALTER TABLE `tblinvoice`
  ADD PRIMARY KEY (`Invoiceid`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `tblpurchaseorder`
--
ALTER TABLE `tblpurchaseorder`
  ADD PRIMARY KEY (`poid`);

--
-- Indexes for table `tblquote`
--
ALTER TABLE `tblquote`
  ADD PRIMARY KEY (`quoteid`);

--
-- Indexes for table `tblstaff`
--
ALTER TABLE `tblstaff`
  ADD PRIMARY KEY (`staffid`);

--
-- Indexes for table `tblstockin`
--
ALTER TABLE `tblstockin`
  ADD PRIMARY KEY (`stockinid`);

--
-- Indexes for table `tblstockout`
--
ALTER TABLE `tblstockout`
  ADD PRIMARY KEY (`stockoutid`);

--
-- Indexes for table `tblsupplier`
--
ALTER TABLE `tblsupplier`
  ADD PRIMARY KEY (`supplierid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
