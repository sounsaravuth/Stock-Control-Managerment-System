package Database;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.Statement;

import javax.swing.JOptionPane;

public interface IDatabase {
	public void FetchData();
	public void InsertData();
	public void UpdateData() ;
	public void DeleteData() ;	
	public void ClearData();
class stockdb{
	public Connection connection = null;
	public PreparedStatement pt = null;
	public ResultSet rs = null;
	public Statement st = null;
	public CallableStatement calls = null;
	// Database Connection To StockMS
	public void DatabaseConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
//			JOptionPane.showMessageDialog(null, "Connection Ok");
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	// Insert Update Delete
	public void SpecialRecord(String SQL) {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			 pt = connection.prepareStatement(SQL);
			 pt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	//Fetch Record From Database To Display Jtable
	public void Displaydb(String SQL) {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			 pt =  connection.prepareStatement(SQL);	
			 rs = pt.executeQuery();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

}
}
