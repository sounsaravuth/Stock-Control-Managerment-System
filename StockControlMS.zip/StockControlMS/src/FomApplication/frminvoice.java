package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import com.toedter.calendar.JDateChooser;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class frminvoice implements IDatabase {

 JFrame frameinvoice;
stockdb stockdbs = new stockdb();
private JTable table;
private JTextField txtinvoiceid;
private JTextField txtpurchasdate;
private JTextField txtprice;
private JTextField txtsupplierid;
JComboBox<String> cbopurchas = new JComboBox<String>();
private JTextField txtpun;
JDateChooser txtdate = new JDateChooser();
SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
String date = sdf.format(txtdate.getDate());
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frminvoice window = new frminvoice();
					window.frameinvoice.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frminvoice() {
		initialize();
		stockdbs.DatabaseConnection();
		cbopurchas.addItem("Select Purchase ID");
		cbopurchas.setSelectedIndex(0);
		FetchRecordPurchase();
		FetchData();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameinvoice = new JFrame();
		frameinvoice.setBounds(100, 100, 1099, 573);
		frameinvoice.setLocationRelativeTo(null);
		frameinvoice.setUndecorated(true);
		frameinvoice.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameinvoice.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_invoice_100px.png"));
		lblNewLabel.setBounds(10, 11, 137, 125);
		frameinvoice.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("STOCK MANAGERMENT SYSTEM INVOICE");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(256, 21, 591, 94);
		frameinvoice.getContentPane().add(lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 326, 758, 236);
		frameinvoice.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtinvoiceid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				try {
					Date dates = (Date) new SimpleDateFormat("yyyy-MM-dd").parse((String)tModel.getValueAt(table.getSelectedRow(), 1).toString());
					txtdate.setDate(dates);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
				
			}
		});
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.setShowGrid(false);
		scrollPane.setViewportView(table);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Invoice", TitledBorder.CENTER, TitledBorder.TOP, null, Color.GREEN));
		panel.setBounds(10, 126, 1079, 189);
		frameinvoice.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Invoice ID");
		lblNewLabel_2.setBounds(10, 11, 127, 30);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		
		JLabel lblNewLabel_2_1 = new JLabel("Invoice Date");
		lblNewLabel_2_1.setBounds(10, 52, 127, 30);
		panel.add(lblNewLabel_2_1);
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		
		txtinvoiceid = new JTextField();
		txtinvoiceid.setBounds(157, 12, 216, 30);
		panel.add(txtinvoiceid);
		txtinvoiceid.setColumns(10);
		
		JDateChooser txtdate = new JDateChooser();
		txtdate.setBounds(157, 52, 216, 30);
		panel.add(txtdate);
		
		JLabel lblNewLabel_2_2 = new JLabel("Purchas ID");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_2_2.setBounds(10, 93, 127, 30);
		panel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Purchas Date");
		lblNewLabel_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_2_2_1.setBounds(10, 133, 127, 30);
		panel.add(lblNewLabel_2_2_1);
		
		txtpurchasdate = new JTextField();
		txtpurchasdate.setForeground(Color.RED);
		txtpurchasdate.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpurchasdate.setEnabled(false);
		txtpurchasdate.setColumns(10);
		txtpurchasdate.setBounds(157, 134, 216, 30);
		panel.add(txtpurchasdate);
		
		txtprice = new JTextField();
		txtprice.setForeground(Color.RED);
		txtprice.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtprice.setEnabled(false);
		txtprice.setColumns(10);
		txtprice.setBounds(728, 52, 216, 30);
		panel.add(txtprice);
		
		JLabel lblNewLabel_2_2_1_1 = new JLabel("Price");
		lblNewLabel_2_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_2_2_1_1.setBounds(574, 52, 127, 30);
		panel.add(lblNewLabel_2_2_1_1);
		
		JLabel lblNewLabel_2_2_1_1_1 = new JLabel("Supplier ID");
		lblNewLabel_2_2_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_2_2_1_1_1.setBounds(574, 93, 127, 30);
		panel.add(lblNewLabel_2_2_1_1_1);
		
		txtsupplierid = new JTextField();
		txtsupplierid.setForeground(Color.RED);
		txtsupplierid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtsupplierid.setEnabled(false);
		txtsupplierid.setColumns(10);
		txtsupplierid.setBounds(728, 93, 216, 30);
		panel.add(txtsupplierid);
		
		
		cbopurchas.setBounds(157, 93, 216, 30);
		panel.add(cbopurchas);
		
		txtpun = new JTextField();
		txtpun.setForeground(Color.RED);
		txtpun.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpun.setEnabled(false);
		txtpun.setColumns(10);
		txtpun.setBounds(728, 11, 216, 30);
		panel.add(txtpun);
		
		JLabel lblNewLabel_2_2_1_2 = new JLabel("Purchas Number");
		lblNewLabel_2_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_2_2_1_2.setBounds(592, 11, 127, 30);
		panel.add(lblNewLabel_2_2_1_2);
		cbopurchas.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				try {
					String sql = "Select * from tblpurchaseorder where poid=?";
					stockdbs.pt = stockdbs.connection.prepareStatement(sql);	
					stockdbs.pt.setString(1, (String)cbopurchas.getSelectedItem());
					
					stockdbs.rs = stockdbs.pt.executeQuery();
					while (stockdbs.rs.next()) {
						txtpun.setText(stockdbs.rs.getString("ponumber"));
						txtpurchasdate.setText(stockdbs.rs.getString("podate"));
						txtprice.setText(stockdbs.rs.getString("povalue"));
						txtsupplierid.setText(stockdbs.rs.getString("supplierid"));
												
					}
				} catch (Exception e2) {
					// TODO: handle exception
				}
			}
			
		});
		
		JButton btnNewButton = new JButton("Add To Invoice");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(789, 326, 277, 36);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
					InsertData();
					FetchData();
					ClearData();
			}
			
		});
		frameinvoice.getContentPane().add(btnNewButton);
		
		JButton btnBackToMenu = new JButton("Back To Menu");
		btnBackToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain main = new frmMain();
				main.MainFram.setVisible(true);
				frameinvoice.dispose();
			}
		});
		btnBackToMenu.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnBackToMenu.setBounds(812, 79, 277, 36);
		frameinvoice.getContentPane().add(btnBackToMenu);
	}

	public void FetchRecordPurchase() {
		try {
			String sql= "select * from tblpurchaseorder";
			stockdbs.st = stockdbs.connection.createStatement();			
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			while (stockdbs.rs.next()) {
				cbopurchas.addItem(stockdbs.rs.getString("poid"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblinvoice");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

	@Override
	public void InsertData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.SpecialRecord("Insert Into tblinvoice values('"+txtinvoiceid.getText()+"','"+date+"','"+txtpun.getText()+"','"+txtpurchasdate.getText()+"','"+txtprice.getText()+"','"+txtsupplierid.getText()+"')");
			JOptionPane.showMessageDialog(null, "Invoice Add New Succesfully !'"+txtinvoiceid.getText()+"'" ,"Record Save",JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void UpdateData() {
		try {
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.SpecialRecord("Delete from tblinvoice where Invoiceid='"+txtinvoiceid.getText()+"'");
			JOptionPane.showMessageDialog(null, "Invoice Delete Succesfully !'"+txtinvoiceid.getText()+"'" ,"Record Delete",JOptionPane.ERROR_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		txtinvoiceid.setText("");
		txtprice.setText("");
		txtpun.setText("");
		txtpurchasdate.setText("");
		txtsupplierid.setText("");
		cbopurchas.setSelectedIndex(0);
		
	}
}
