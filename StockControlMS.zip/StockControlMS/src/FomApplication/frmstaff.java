package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
//import javax.swing.text.DateFormatter;

import java.awt.Font;
import javax.swing.JTabbedPane;
import javax.swing.ImageIcon;
//import rojerusan.RSTableMetro;
//import rojerusan.RSMetroTextFullPlaceHolder;
//import rojerusan.RSLabelVerticalDBeanInfo;
//import rojerusan.RSComboMetroBeanInfo;
import javax.swing.JComboBox;
//import rojerusan.RSDateChooser;
//import rojerusan.RSButtonIconI;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
//import java.sql.Date;
import java.util.Date;
import java.sql.DriverManager;
//import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;

//import java.awt.Button;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import com.toedter.calendar.JDateChooser;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
//import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class frmstaff implements IDatabase {
	
	
	
	stockdb stockdbs = new stockdb();
	//Declare Variable Textbox

	
	JFrame staffframe;
	private JTextField txtids;
	private JTextField txtfullname;
	private JTextField txtpob;
	private JTextField txttel;
	private JTextField txtaddress;
	private JTextField txtemail;
	private JTextField txtsalary;
	private JTextField txtusername;
	private JTextField txtpassword;
	private JTable table;
	JComboBox<String> cbogender = new JComboBox<String>();
	JComboBox<String> cborole = new JComboBox<String>();
	private JTextField txtsearch;
	JDateChooser txtdate = new JDateChooser();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String date = sdf.format(txtdate.getDate());

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmstaff window = new frmstaff();
					window.staffframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmstaff() {
		initialize();
		//Connection
		stockdbs.DatabaseConnection();
		//Geander Select
		 FetchData();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initialize() {
		staffframe = new JFrame();
		staffframe.setBounds(100, 100, 1447, 827);
		staffframe.setLocationRelativeTo(null);
		staffframe.setUndecorated(true);
		staffframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		staffframe.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1431, 86);
		staffframe.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STAFF INFORMATION");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(527, 11, 494, 64);
		panel.add(lblNewLabel);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 102, 1411, 253);
		staffframe.getContentPane().add(tabbedPane);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("STAFF", new ImageIcon("D:\\Java Application\\StockControlMS\\bin\\Image\\icons8_staff_30px.png"), panel_1, null);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1.setBounds(95, 35, 46, 14);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("FULLNAME");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_1.setBounds(10, 86, 131, 22);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("GENDER");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_2.setBounds(43, 127, 98, 22);
		panel_1.add(lblNewLabel_1_2);
		
		
		
		cbogender.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		cbogender.setModel(new DefaultComboBoxModel(new String[] {"Chooser Gender", "Male", "Female"}));
		cbogender.setSelectedIndex(0);
	
		cbogender.setBounds(151, 124, 244, 31);
		panel_1.add(cbogender);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("DOB");
		lblNewLabel_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_2_1.setBounds(43, 176, 98, 22);
		panel_1.add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_3 = new JLabel("POB");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_3.setBounds(542, 20, 46, 14);
		panel_1.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("TEL");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_4.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_4.setBounds(542, 76, 46, 14);
		panel_1.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_4_1 = new JLabel("ADDRESS");
		lblNewLabel_1_4_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_4_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_4_1.setBounds(490, 135, 98, 14);
		panel_1.add(lblNewLabel_1_4_1);
		
		JLabel lblNewLabel_1_4_2 = new JLabel("EMAIL");
		lblNewLabel_1_4_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_4_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_4_2.setBounds(514, 184, 71, 14);
		panel_1.add(lblNewLabel_1_4_2);
		
		JLabel lblNewLabel_1_4_2_1 = new JLabel("SALARY");
		lblNewLabel_1_4_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_4_2_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_4_2_1.setBounds(883, 21, 71, 14);
		panel_1.add(lblNewLabel_1_4_2_1);
		
		txtids = new JTextField();
		txtids.setBounds(151, 18, 244, 40);
		panel_1.add(txtids);
		txtids.setColumns(10);
		
		txtfullname = new JTextField();
		txtfullname.setColumns(10);
		txtfullname.setBounds(151, 74, 244, 40);
		panel_1.add(txtfullname);
		
		txtpob = new JTextField();
		txtpob.setColumns(10);
		txtpob.setBounds(598, 6, 244, 40);
		panel_1.add(txtpob);
		
		txttel = new JTextField();
		txttel.setColumns(10);
		txttel.setBounds(598, 58, 244, 40);
		panel_1.add(txttel);
		
		txtaddress = new JTextField();
		txtaddress.setColumns(10);
		txtaddress.setBounds(598, 109, 244, 40);
		panel_1.add(txtaddress);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBounds(598, 160, 244, 40);
		panel_1.add(txtemail);
		
		txtsalary = new JTextField();
		txtsalary.setColumns(10);
		txtsalary.setBounds(964, 9, 244, 40);
		panel_1.add(txtsalary);
		
		
		txtdate.getSpinner().setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtdate.setBounds(151, 166, 244, 30);
		panel_1.add(txtdate);
		
		JButton btnNewButton = new JButton("ADD NEW STAFF");
		btnNewButton.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_staff_30px.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				FetchData();
				ClearData();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(964, 58, 244, 40);
		panel_1.add(btnNewButton);
		
		JButton btnBackToDashboard = new JButton("Back To Dashboard");
		btnBackToDashboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain fMain = new frmMain();
				fMain.MainFram.setVisible(true);
				staffframe.dispose();
			}
		});
		btnBackToDashboard.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBackToDashboard.setBounds(1218, 6, 183, 40);
		panel_1.add(btnBackToDashboard);
		
		JButton btnEdit = new JButton("EDIT");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateData();
				FetchData();
				ClearData();
			}
		});
		btnEdit.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_update_30px.png"));
		btnEdit.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnEdit.setBounds(964, 107, 244, 40);
		panel_1.add(btnEdit);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_delete_30px.png"));
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnDelete.setBounds(964, 158, 244, 40);
		btnDelete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				DeleteData();
				FetchData();
				ClearData();
			}
			
		});
		panel_1.add(btnDelete);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("REGISTER", new ImageIcon("D:\\Java Application\\StockControlMS\\bin\\Image\\icons8_registration_30px.png"), panel_2, null);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("USERNAME");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_1_1.setBounds(36, 63, 131, 22);
		panel_2.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("PASSWORD");
		lblNewLabel_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_1_2.setBounds(36, 121, 131, 22);
		panel_2.add(lblNewLabel_1_1_2);
	
		
		cborole.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		cborole.setModel(new DefaultComboBoxModel(new String[] {"Choose Role", "Admin", "User"}));
		cborole.setBounds(177, 13, 244, 31);
		panel_2.add(cborole);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("ROLE");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_1_1_1.setBounds(36, 21, 131, 22);
		panel_2.add(lblNewLabel_1_1_1_1);
		
		txtusername = new JTextField();
		txtusername.setColumns(10);
		txtusername.setBounds(177, 55, 244, 40);
		panel_2.add(txtusername);
		
		txtpassword = new JTextField();
		txtpassword.setColumns(10);
		txtpassword.setBounds(177, 106, 244, 40);
		panel_2.add(txtpassword);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("SEARCH RECORD", new ImageIcon("D:\\Java Application\\StockControlMS\\bin\\Image\\icons8_search_30px.png"), panel_3, null);
		panel_3.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(null, "Record Search", TitledBorder.CENTER, TitledBorder.TOP, null, Color.RED));
		panel_4.setBounds(338, 57, 768, 75);
		panel_3.add(panel_4);
		panel_4.setLayout(null);
		
		txtsearch = new JTextField();
		txtsearch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				TableRowSorter<DefaultTableModel> tRowSorter = new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tRowSorter);
				tRowSorter.setRowFilter(RowFilter.regexFilter(txtsearch.getText().trim()));
			}
		});
		txtsearch.setBounds(10, 21, 748, 43);
		panel_4.add(txtsearch);
		txtsearch.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 381, 1411, 342);
		staffframe.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtids.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				txtfullname.setText(tModel.getValueAt(table.getSelectedRow(),1).toString());
				cbogender.setSelectedItem(tModel.getValueAt(table.getSelectedRow(),2).toString());
				
				try {
				
					Date dates = (Date) new SimpleDateFormat("yyyy-MM-dd").parse((String)tModel.getValueAt(table.getSelectedRow(), 3).toString());
					txtdate.setDate(dates);
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2);
				}
				txtpob.setText(tModel.getValueAt(table.getSelectedRow(),4).toString());
				txttel.setText(tModel.getValueAt(table.getSelectedRow(),5).toString());
				txtaddress.setText(tModel.getValueAt(table.getSelectedRow(),6).toString());
				txtemail.setText(tModel.getValueAt(table.getSelectedRow(),7).toString());
				cborole.setSelectedItem(tModel.getValueAt(table.getSelectedRow(),8).toString());
				txtsalary.setText(tModel.getValueAt(table.getSelectedRow(),9).toString());
				txtusername.setText(tModel.getValueAt(table.getSelectedRow(),10).toString());
				txtpassword.setText(tModel.getValueAt(table.getSelectedRow(),11).toString());
			}
		});
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.setShowGrid(false);
		scrollPane.setViewportView(table);
	}

	
	
	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblstaff");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e , null, JOptionPane.ERROR_MESSAGE);
		}

	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Delete Supplier Record ?","Question",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.ERROR_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Update tblstaff set fullname='"+txtfullname.getText()+"',gender='"+cbogender.getSelectedItem()+"',dob='"+date+"',pob='"+txtpob.getText()+"',tel='"+txttel.getText()+"',address='"+txtaddress.getText()+"',email='"+txtemail.getText()+"',role='"+cborole.getSelectedItem()+"',salary='"+txtsalary.getText()+"',username='"+txtusername.getText()+"',password='"+txtpassword.getText()+"' where staffid='"+txtids.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Staff Update'"+txtids.getText()+"'","Record Update",JOptionPane.ERROR_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
		}
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Delete Supplier Record ?","Question",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.ERROR_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("delete from tblstaff where staffid='"+txtids.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Staff Delete'"+txtids.getText()+"'","Record Delete",JOptionPane.ERROR_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
		}
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		txtids.setText("");
		txtfullname.setText("");
		cbogender.setSelectedIndex(0);
		txtpob.setText("");
		txttel.setText("");
		txtaddress.setText("");
		txtemail.setText("");
		cborole.setSelectedIndex(0);
		txtsalary.setText("");
		txtusername.setText("");
		txtpassword.setText("");
	}

	@Override
	public void InsertData() {
		// TODO Auto-generated method stub
		if(txtids.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "ID Request ?" ,"validate", JOptionPane.WARNING_MESSAGE);
			txtids.requestFocus();
			return;
		}else if (txtfullname.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "Fullname Request ?" ,"validate", JOptionPane.WARNING_MESSAGE);
			txtfullname.requestFocus();
			return;
		}else if (cbogender.getSelectedItem().equals("")) {
			JOptionPane.showMessageDialog(null, "Gender Request ?" ,"validate", JOptionPane.WARNING_MESSAGE);
			((Component) cbogender.getSelectedItem()).requestFocus();
			return;
		}else if (txtpob.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "Place of birth Request ?" ,"validate", JOptionPane.WARNING_MESSAGE);
			txtpob.requestFocus();
			return;
		}else if (txttel.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "Tel Request ?" ,"validate", JOptionPane.WARNING_MESSAGE);
			txttel.requestFocus();
			return;
		}else if (txtusername.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "UserName Request ?" ,"validate", JOptionPane.WARNING_MESSAGE);
			txtusername.requestFocus();
			return;
		}else if (txtpassword.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "Password Request ?" ,"validate", JOptionPane.WARNING_MESSAGE);
			txtpassword.requestFocus();
			return;
		}
		
		
		try {
			stockdbs.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			String sql = "select * from tblstaff where staffid='"+txtids.getText()+"'";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			if(stockdbs.rs.next() == true) {
				JOptionPane.showMessageDialog(null, "Record Extist '"+txtids.getText()+"'!" , "Warning" , JOptionPane.WARNING_MESSAGE);
				return;
			}else {
				stockdbs.SpecialRecord("Insert Into tblstaff values('"+txtids.getText()+"','"+txtfullname.getText()+"','"+cbogender.getSelectedItem()+"','"+date+"','"+txtpob.getText()+"','"+txttel.getText()+"','"+txtaddress.getText()+"','"+txtemail.getText()+"','"+cborole.getSelectedItem()+"','"+txtsalary.getText()+"','"+txtusername.getText()+"','"+txtpassword.getText()+"')");
				JOptionPane.showMessageDialog(null, "Record Staff Save !'"+txtids.getText()+"'" ,"Record Save",JOptionPane.INFORMATION_MESSAGE);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
}
