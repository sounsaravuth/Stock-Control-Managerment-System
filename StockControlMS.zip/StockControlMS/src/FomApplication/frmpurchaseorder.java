package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;

import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;

public class frmpurchaseorder implements IDatabase {

	 JFrame frame;
	private JTextField txtpid;
	private JTextField txtpv;
	private JTextField txtsupplierid;
	private JTextField txtpn;
	private JTextField txtsearch;
	private JTable table;
	stockdb stockdbs = new stockdb();
	JComboBox<String> cbosuppliername = new JComboBox<String>();
	JDateChooser txtdate = new JDateChooser();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String date = sdf.format(txtdate.getDate());
	
	double pv ;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmpurchaseorder window = new frmpurchaseorder();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmpurchaseorder() {
		initialize();
		stockdbs.DatabaseConnection();
		FetchData();
		cbosuppliername.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "Select * from tblsupplier where suppliername=?";
					stockdbs.pt = stockdbs.connection.prepareStatement(sql);	
					stockdbs.pt.setString(1, (String)cbosuppliername.getSelectedItem());
					stockdbs.rs = stockdbs.pt.executeQuery();
					while (stockdbs.rs.next()) {
						txtsupplierid.setText(stockdbs.rs.getString("supplierid"));						
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
			}
		});
		cbosuppliername.addItem("Select Supplier Name");
		cbosuppliername.setSelectedIndex(0);
		FetchRecordSupplierid();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1537, 714);
		frame.setLocationRelativeTo(null);
		frame.setUndecorated(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1537, 65);
		frame.getContentPane().add(panel);
		
		JLabel lblPurchaseOrder = new JLabel("purchase order");
		lblPurchaseOrder.setHorizontalAlignment(SwingConstants.CENTER);
		lblPurchaseOrder.setForeground(Color.WHITE);
		lblPurchaseOrder.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblPurchaseOrder.setBounds(630, 11, 298, 43);
		panel.add(lblPurchaseOrder);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1.setBounds(10, 76, 497, 588);
		frame.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("Purchase ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(12, 121, 101, 25);
		panel_1.add(lblNewLabel_1);
		
		txtpid = new JTextField();
		txtpid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpid.setColumns(10);
		txtpid.setBounds(123, 120, 163, 28);
		panel_1.add(txtpid);
		
		JLabel lblNewLabel_1_1 = new JLabel("Purchase No");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(22, 157, 91, 25);
		panel_1.add(lblNewLabel_1_1);
		
		
		txtdate.getSpinner().setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtdate.setBounds(123, 189, 163, 30);
		panel_1.add(txtdate);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Purchase Date");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(12, 194, 101, 25);
		panel_1.add(lblNewLabel_1_1_1);
		
		txtpv = new JTextField();
		txtpv.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpv.setColumns(10);
		txtpv.setBounds(123, 232, 163, 28);
	
		
		panel_1.add(txtpv);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Purchase Value");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(12, 233, 101, 25);
		panel_1.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Supplier Name");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1.setBounds(10, 269, 103, 25);
		panel_1.add(lblNewLabel_1_1_1_1_1);
		
		
		cbosuppliername.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		cbosuppliername.setBounds(123, 271, 163, 23);
		panel_1.add(cbosuppliername);
		
		txtsupplierid = new JTextField();
		txtsupplierid.setForeground(Color.RED);
		txtsupplierid.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtsupplierid.setEnabled(false);
		txtsupplierid.setColumns(10);
		txtsupplierid.setBounds(123, 302, 163, 28);
		panel_1.add(txtsupplierid);
		
		JLabel lblNewLabel_1_2 = new JLabel("Supplier ID");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(41, 305, 72, 25);
		panel_1.add(lblNewLabel_1_2);
		
		JButton btnDeletePurchase = new JButton("Delete Purchase");
		btnDeletePurchase.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_delete_30px.png"));
		btnDeletePurchase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteData();
				FetchData();
				ClearData();
			}
		});
		btnDeletePurchase.setBounds(116, 382, 170, 30);
		panel_1.add(btnDeletePurchase);
		
		JButton btnUpdatePurchase = new JButton("Update Purchase");
		btnUpdatePurchase.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_update_30px.png"));
		btnUpdatePurchase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateData();
				FetchData();
				ClearData();
			}
		});
		btnUpdatePurchase.setBounds(116, 423, 170, 30);
		panel_1.add(btnUpdatePurchase);
		
		JButton btnPurchaseOrder = new JButton("Purchase Order ");
		btnPurchaseOrder.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_purchase_order_30px.png"));
		btnPurchaseOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				FetchData();
				ClearData();
			}
		});
		btnPurchaseOrder.setBounds(116, 341, 170, 30);
		panel_1.add(btnPurchaseOrder);
		
		JLabel lblNewLabel_2 = new JLabel("purchase order");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_2.setBounds(132, 41, 298, 43);
		panel_1.add(lblNewLabel_2);
		
		txtpn = new JTextField();
		txtpn.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpn.setColumns(10);
		txtpn.setBounds(123, 157, 163, 28);
		panel_1.add(txtpn);
		
		JButton btnBackToMenu = new JButton("BACK TO MENU");
		btnBackToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain main = new frmMain();
				main.MainFram.setVisible(true);
				frame.dispose();
			}
		});
		btnBackToMenu.setBounds(116, 464, 170, 30);
		panel_1.add(btnBackToMenu);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(new TitledBorder(null, "SEARCH RECORD", TitledBorder.CENTER, TitledBorder.TOP, null, Color.RED));
		panel_2.setBounds(517, 76, 994, 65);
		frame.getContentPane().add(panel_2);
		txtsearch = new JTextField();
		txtsearch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				TableRowSorter<DefaultTableModel> tRowSorter = new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tRowSorter);
				tRowSorter.setRowFilter(RowFilter.regexFilter(txtsearch.getText().trim()));
			}
		});
		txtsearch.setColumns(10);
		txtsearch.setBounds(10, 22, 974, 32);
		panel_2.add(txtsearch);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(517, 152, 994, 512);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		table.setShowGrid(false);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtpid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				txtpn.setText(tModel.getValueAt(table.getSelectedRow(),1).toString());
				try {
					Date dates = (Date) new SimpleDateFormat("yyyy-MM-dd").parse((String)tModel.getValueAt(table.getSelectedRow(), 2).toString());
					txtdate.setDate(dates);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
				txtpv.setText(tModel.getValueAt(table.getSelectedRow(),3).toString());
				txtsupplierid.setText(tModel.getValueAt(table.getSelectedRow(),4).toString());
			}
		});
		scrollPane.setViewportView(table);
	}

	
	public void FetchRecordSupplierid() {
		try {
			String sql= "select * from tblsupplier";
			stockdbs.st = stockdbs.connection.createStatement();			
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			while (stockdbs.rs.next()) {
				cbosuppliername.addItem(stockdbs.rs.getString("suppliername"));
			}
			
			} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblpurchaseorder");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void InsertData() {
		String poid  = txtpid.getText() , pon = txtpn.getText() , pov = txtpv.getText() , supplierid = txtsupplierid.getText();
		int purchase_value = 0;
		if(poid.equals("")) {
			JOptionPane.showMessageDialog(null, "Purchase ID Request !" ,"validate" , JOptionPane.WARNING_MESSAGE);
			txtpid.requestFocus();
			return;
		}else if (pon.equals("")) {
			JOptionPane.showMessageDialog(null, "Purchase Number Request !" ,"validate" , JOptionPane.WARNING_MESSAGE);
			txtpn.requestFocus();
			return;
		}else if (pov.equals("")) {
			JOptionPane.showMessageDialog(null, "Purchase Value Request !" ,"validate" , JOptionPane.WARNING_MESSAGE);
			txtpv.requestFocus();
			return;
		}else if (supplierid.equals("")) {
			JOptionPane.showMessageDialog(null, "Purchase ID Request !" ,"validate" , JOptionPane.WARNING_MESSAGE);
			txtsupplierid.requestFocus();
			return;
		}
		
		if(purchase_value != 0) {
			JOptionPane.showMessageDialog(null, "Purchase Empty!","Purchase Empty",JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		try {
			stockdbs.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			String sql = "select * from tblpurchaseorder where poid='"+txtpid.getText()+"'";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			if(stockdbs.rs.next() == true) {
				JOptionPane.showMessageDialog(null, "Record Extist '"+txtpid.getText()+"!" , "Warning" , JOptionPane.WARNING_MESSAGE);
				return;
			}
			stockdbs.SpecialRecord("INSERT INTO tblpurchaseorder values('"+txtpid.getText()+"','"+txtpn.getText()+"','"+date+"','"+txtpv.getText()+"','"+txtsupplierid.getText()+"')");
			JOptionPane.showMessageDialog(null, "Record purchaseorder Order Successfully  !'"+txtpid.getText()+"'" ,"Record Save",JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

	@Override
	public void UpdateData() {
		if(JOptionPane.showConfirmDialog(null, "Do You want To Update purchaseorder ?","Question",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Update tblpurchaseorder set ponumber='"+txtpn.getText()+"',podate='"+date+"',povalue='"+txtpv.getText()+"',supplierid='"+txtsupplierid.getText()+"' where poid='"+txtpid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record purchaseorder Order Update  !'"+txtpid.getText()+"'" ,"Record Update",JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e);
			}	
		}
	
	}

	@Override
	public void DeleteData() {
		if(JOptionPane.showConfirmDialog(null, "Do You want To Update purchaseorder ?","Question",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Delete from tblpurchaseorder where poid='"+txtpid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record purchaseorder Order Delete  !'"+txtpid.getText()+"'" ,"Record Delete",JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e);
			}	
		}
	
	}

	@Override
	public void ClearData() {
		txtpid.setText("");
		txtpn.setText("");
		txtpv.setText("");
		txtsupplierid.setText("");
		cbosuppliername.setSelectedIndex(0);
		
	}
}
