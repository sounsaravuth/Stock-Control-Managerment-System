package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.Font;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.JScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.border.TitledBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmproductsearch implements IDatabase {

	 JFrame frame;
	private JTable table;
	stockdb stockdbs = new stockdb();
	private JScrollPane scrollPane;
	private JPanel panel_1;
	private JTextField txtsearch;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmproductsearch window = new frmproductsearch();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmproductsearch() {
		initialize();
		stockdbs.DatabaseConnection();
		FetchData();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1323, 758);
		frame.setLocationRelativeTo(null);
		frame.setUndecorated( true );
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1323, 89);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PRODUCT SEARCH");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(409, 11, 583, 67);
		panel.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 201, 1303, 546);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.setShowGrid(false);
	
		table.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
			}
		});
		scrollPane.setViewportView(table);
		
		panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Find Product", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 128, 0)));
		panel_1.setBounds(10, 124, 1131, 66);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		txtsearch = new JTextField();
		txtsearch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				TableRowSorter<DefaultTableModel> tRowSorter = new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tRowSorter);
				tRowSorter.setRowFilter(RowFilter.regexFilter(txtsearch.getText().trim()));
			}
		});
		txtsearch.setBounds(10, 23, 1111, 32);
		panel_1.add(txtsearch);
		txtsearch.setColumns(10);
		
		JButton btnNewButton = new JButton("Back To Product");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmproduct producrs = new frmproduct();
				producrs.frame.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton.setForeground(Color.ORANGE);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(1149, 146, 152, 40);
		frame.getContentPane().add(btnNewButton);
	}

	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("SELECT tblproduct.productid,tblproduct.productname,tblcategory.categoryid,tblcategory.categoryname FROM tblproduct INNER JOIN tblcategory on tblproduct.categoryid = tblcategory.categoryid");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void InsertData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		
	}
}
