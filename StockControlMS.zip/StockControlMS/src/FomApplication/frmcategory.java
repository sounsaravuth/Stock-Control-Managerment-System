package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import rojerusan.RSTableMetro;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.nio.channels.NonWritableChannelException;
import java.sql.DriverManager;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class frmcategory implements IDatabase {

JFrame framecategory;
	private JTextField txtcateid;
	private JTextField txtcatename;
	RSTableMetro tableMetro = new RSTableMetro();
	stockdb stockdbs = new stockdb();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmcategory window = new frmcategory();
					window.framecategory.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmcategory() {
		initialize();
		stockdbs.DatabaseConnection();
		FetchData();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		framecategory = new JFrame();
		framecategory.setBounds(100, 100, 1132, 511);
		framecategory.setLocationRelativeTo(null);
		framecategory.setUndecorated(true);
		framecategory.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		framecategory.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel.setBounds(10, 29, 389, 432);
		framecategory.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CATEGORY ID");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel.setBounds(41, 100, 111, 22);
		panel.add(lblNewLabel);
		
		txtcateid = new JTextField();
		txtcateid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtcateid.setBounds(162, 96, 171, 32);
		panel.add(txtcateid);
		txtcateid.setColumns(10);
		
		JLabel lblCategoryName = new JLabel("CATEGORY NAME");
		lblCategoryName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCategoryName.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblCategoryName.setBounds(27, 163, 125, 32);
		panel.add(lblCategoryName);
		
		txtcatename = new JTextField();
		txtcatename.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtcatename.setColumns(10);
		txtcatename.setBounds(162, 163, 171, 32);
		panel.add(txtcatename);
		
		JButton btnNewButton = new JButton("ADD NEW CATEGORY");
		btnNewButton.setBounds(162, 217, 171, 32);
		panel.add(btnNewButton);
		
		JButton btnUpdateCategory = new JButton("UPDATE CATEGORY");
		btnUpdateCategory.setBounds(162, 260, 171, 32);
		panel.add(btnUpdateCategory);
		btnUpdateCategory.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				UpdateData();
				FetchData();
				ClearData();
			}
			
		});
		
		JButton btnDeleteCategory = new JButton("DELETE CATEGORY");
		btnDeleteCategory.setBounds(162, 303, 171, 32);
		panel.add(btnDeleteCategory);
		
		JButton btnBackToProduct = new JButton("BACK TO PRODUCT");
		btnBackToProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmproduct products = new frmproduct();
				products.frame.setVisible(true);
				framecategory.dispose();
			}
		});
		btnBackToProduct.setBounds(162, 346, 171, 32);
		panel.add(btnBackToProduct);
		btnDeleteCategory.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				DeleteData();
				FetchData();
				ClearData();
			}
			
		});
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				InsertData();
				FetchData();
				ClearData();
			}
			
		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(446, 29, 632, 432);
		framecategory.getContentPane().add(scrollPane);
		tableMetro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)tableMetro.getModel();
				txtcateid.setText(tModel.getValueAt(tableMetro.getSelectedRow(),0).toString());
				txtcatename.setText(tModel.getValueAt(tableMetro.getSelectedRow(),1).toString());
				
			}
		});
		tableMetro.setFuenteHead(new Font("Times New Roman", Font.BOLD, 13));
		scrollPane.setViewportView(tableMetro);
		tableMetro.setShowGrid(false);
	}

	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
			try {
				stockdbs.Displaydb("Select * from tblcategory");
				tableMetro.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
	}

	@Override
	public void InsertData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			String sql = "select * from tblcategory where categoryid='"+txtcateid.getText()+"'";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			if(stockdbs.rs.next() == true) {
				JOptionPane.showMessageDialog(null, "Record Extist '"+txtcateid.getText()+"'! "+txtcateid.getText()+"'!" , "Warning" , JOptionPane.WARNING_MESSAGE);
				return;
			}else {
				stockdbs.SpecialRecord("Insert into tblcategory values('"+txtcateid.getText()+"' , '"+txtcatename.getText()+"')");
				JOptionPane.showMessageDialog(null, "Category Add New Successfully'"+txtcateid.getText()+"'","Record Save" ,JOptionPane.INFORMATION_MESSAGE);	
			}
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.SpecialRecord("Update tblcategory set categoryname='"+txtcatename.getText()+"' where categoryid='"+txtcateid.getText()+"'");
			JOptionPane.showMessageDialog(null, "Category Update Successfully'"+txtcateid.getText()+"'","Record Update" ,JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
			try {
				stockdbs.SpecialRecord("Delete from tblcategory where categoryid='"+txtcateid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Category Delete Successfully'"+txtcateid.getText()+"'","Record Delete" ,JOptionPane.ERROR_MESSAGE);
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e);
			}
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		txtcateid.setText("");
		txtcatename.setText("");
	}
}
