package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.UIManager;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class frmsupplier implements IDatabase {
	stockdb stockdbs = new stockdb();
	 JFrame supplierframe;
	private JTable table;
	private JTextField txtsupid;
	private JTextField txtsupname;
	private JTextField txttel;
	private JTextField txtemail;
	private JTextField txtsearch;
	private JTextField txtaddress;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmsupplier window = new frmsupplier();
					window.supplierframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmsupplier() {
		initialize();
		stockdbs.DatabaseConnection();
		FetchData();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		supplierframe = new JFrame();
		supplierframe.setBounds(100, 100, 1237, 581);
		supplierframe.setLocationRelativeTo(null);
		supplierframe.setUndecorated(true);
		supplierframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		supplierframe.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1237, 83);
		supplierframe.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SUPPLIER COMPANY");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel.setBounds(357, 11, 501, 61);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\src\\Image\\icons8_supplier_70px.png"));
		lblNewLabel_1.setBounds(10, 11, 108, 61);
		panel.add(lblNewLabel_1);
		
		JButton btnUpdateSupplier_1_1 = new JButton("X\r\n");
		btnUpdateSupplier_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain fMain = new frmMain();
				fMain.MainFram.setVisible(true);
				supplierframe.dispose();
			}
		});
		btnUpdateSupplier_1_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnUpdateSupplier_1_1.setBounds(1151, 0, 86, 83);
		panel.add(btnUpdateSupplier_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 146, 804, 385);
		supplierframe.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtsupid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				txtsupname.setText(tModel.getValueAt(table.getSelectedRow(),1).toString());
				txttel.setText(tModel.getValueAt(table.getSelectedRow(),2).toString());
				txtaddress.setText(tModel.getValueAt(table.getSelectedRow(),3).toString());
				txtemail.setText(tModel.getValueAt(table.getSelectedRow(),4).toString());
			}
		});
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.setShowGrid(false);
		scrollPane.setViewportView(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1.setBounds(835, 134, 376, 397);
		supplierframe.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Supplier ID");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 65, 103, 27);
		panel_1.add(lblNewLabel_2);
		
		txtsupid = new JTextField();
		txtsupid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtsupid.setBounds(123, 62, 232, 34);
		panel_1.add(txtsupid);
		txtsupid.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("Supplier Name");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_1.setBounds(10, 110, 103, 27);
		panel_1.add(lblNewLabel_2_1);
		
		txtsupname = new JTextField();
		txtsupname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				char c = e.getKeyChar();
				if(Character.isLetter(c) || Character.isWhitespace(c) || Character.isISOControl(c)) {
					txtsupname.setEditable(true);
					
					
				}else {
					txtsupname.setEditable(false);
					JOptionPane.showMessageDialog(null, "Accept Letter Only" , "Validate" , JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		txtsupname.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtsupname.setColumns(10);
		txtsupname.setBounds(123, 107, 232, 34);
		panel_1.add(txtsupname);
		
		JLabel lblNewLabel_2_2 = new JLabel("Tel");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_2.setBounds(10, 160, 103, 27);
		panel_1.add(lblNewLabel_2_2);
		
		txttel = new JTextField();
		txttel.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				char c =e.getKeyChar();
				if(Character.isLetter(c)) {
					txttel.setEditable(false);
					JOptionPane.showMessageDialog(null, "Invlid Number" , "Validate" , JOptionPane.WARNING_MESSAGE);
				}else {
					txttel.setEditable(true);
				}
			}
		});
		txttel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txttel.setColumns(10);
		txttel.setBounds(123, 157, 232, 34);
		panel_1.add(txttel);
		
		JLabel lblNewLabel_2_3 = new JLabel("Email");
		lblNewLabel_2_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_3.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_3.setBounds(10, 251, 103, 27);
		panel_1.add(lblNewLabel_2_3);
		
		txtemail = new JTextField();
		txtemail.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtemail.setColumns(10);
		txtemail.setBounds(123, 248, 232, 34);
		panel_1.add(txtemail);
		
		JButton btnNewButton = new JButton("ADD NEW SUPPLIER");
		btnNewButton.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\src\\Image\\icons8_supplier_30px.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				FetchData();
				ClearData();
			}
		});
		btnNewButton.setBounds(123, 293, 232, 34);
		panel_1.add(btnNewButton);
		
		txtaddress = new JTextField();
		txtaddress.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtaddress.setColumns(10);
		txtaddress.setBounds(123, 202, 232, 34);
		panel_1.add(txtaddress);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Address");
		lblNewLabel_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_2_1.setBounds(10, 213, 103, 27);
		panel_1.add(lblNewLabel_2_2_1);
		
		JButton btnUpdateSupplier = new JButton("UPDATE SUPPLIER");
		btnUpdateSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateData();
				FetchData();
				ClearData();
			}
		});
		btnUpdateSupplier.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\src\\Image\\icons8_update_30px.png"));
		btnUpdateSupplier.setBounds(123, 338, 232, 34);
		panel_1.add(btnUpdateSupplier);
		
		JButton btnUpdateSupplier_1 = new JButton("");
		btnUpdateSupplier_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteData();
				FetchData();
				ClearData();
			}
		});
		btnUpdateSupplier_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\src\\Image\\icons8_trash_30px.png"));
		btnUpdateSupplier_1.setBounds(27, 298, 86, 74);
		panel_1.add(btnUpdateSupplier_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "SEARCH ", TitledBorder.LEADING, TitledBorder.TOP, null, Color.RED));
		panel_2.setBounds(10, 94, 804, 51);
		supplierframe.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		txtsearch = new JTextField();
		txtsearch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				TableRowSorter<DefaultTableModel> tRowSorter = new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tRowSorter);
				tRowSorter.setRowFilter(RowFilter.regexFilter(txtsearch.getText().trim()));
			}
		});
		txtsearch.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		txtsearch.setColumns(10);
		txtsearch.setBounds(10, 11, 784, 34);
		panel_2.add(txtsearch);
	}

	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblsupplier");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	public void InsertData() {
		// TODO Auto-generated method stub
		String supplierid = txtsupid.getText();
		String suppliername = txtsupname.getText();
		String tel  = txttel.getText();
		String address = txtaddress.getText();
		String Email = txtemail.getText();
		if(supplierid.equals("") && suppliername.equals("") && tel.equals("") && address.equals("") && Email.equals("")) {
			JOptionPane.showMessageDialog(null, "Please Fill Informatin !" , "Warning" , JOptionPane.WARNING_MESSAGE);
			txtsupid.requestFocus();
			return;
		}
		
	try {
		stockdbs.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
		String sql = "select * from tblsupplier where supplierid='"+txtsupid.getText()+"'";
		stockdbs.st = stockdbs.connection.createStatement();
		stockdbs.rs = stockdbs.st.executeQuery(sql);
		if(stockdbs.rs.next() == true) {
			JOptionPane.showMessageDialog(null, "Record Extist !" , "Warning" , JOptionPane.WARNING_MESSAGE);
			return;
		}else {
			stockdbs.SpecialRecord("insert into tblsupplier values('"+supplierid+"','"+suppliername+"','"+tel+"','"+address+"','"+Email+"')");
			JOptionPane.showMessageDialog(null, "Record Supplier Save !" , "Record save",JOptionPane.INFORMATION_MESSAGE);
		}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Update Supplier Record ?" , "Question",JOptionPane.YES_NO_CANCEL_OPTION ,JOptionPane.QUESTION_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Update tblsupplier set suppliername='"+txtsupname.getText()+"',tel='"+txttel.getText()+"',address='"+txtaddress.getText()+"',email='"+txtemail.getText()+"' where supplierid='"+txtsupid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Supplier Update !" , "Record Update",JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Delete Supplier Record ?","Question",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.ERROR_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Delete from tblsupplier where supplierid='"+txtsupid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Supplier Delete !" , "Record Delete",JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE);
			}
		}
		
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		txtsupid.setText("");
		txtaddress.setText("");
		txttel.setText("");
		txtemail.setText("");
		txtsupname.setText("");

		
	}
}
