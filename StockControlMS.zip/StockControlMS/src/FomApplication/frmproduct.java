package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;


import java.awt.Panel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.sql.DriverManager;


import javax.swing.ListSelectionModel;
import javax.swing.JComboBox;

public class frmproduct implements IDatabase {

	 JFrame frame;
	private JTextField txtproid;
	private JTextField txtproname;
	private JTable table;
	JTextPane txtdescription = new JTextPane();
	stockdb sdb = new stockdb();
	private JTextField txtcategoryid;
	JComboBox<String> comboBox = new JComboBox<String>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmproduct window = new frmproduct();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmproduct() {
		initialize();
		sdb.DatabaseConnection();
		FetchData();
		comboBox.addItem("Select Category ID");
		comboBox.setSelectedIndex(0);
		
		JButton btnBackToMenu = new JButton("Back To Menu");
		btnBackToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain fMain = new frmMain();
				fMain.MainFram.setVisible(true);
				frame.dispose();
			}
		});
		btnBackToMenu.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnBackToMenu.setBounds(552, 342, 203, 33);
		frame.getContentPane().add(btnBackToMenu);
		
		JButton btnAddMoreCategory = new JButton("Add More Category");
		btnAddMoreCategory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmcategory categorys = new frmcategory();
				categorys.framecategory.setVisible(true);
				frame.dispose();
			}
		});
		btnAddMoreCategory.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnAddMoreCategory.setBounds(115, 386, 203, 33);
		frame.getContentPane().add(btnAddMoreCategory);
		
		JButton btnSearchAllProduct = new JButton("SEARCH ALL PRODUCT");
		btnSearchAllProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmproductsearch producFrmproductsearch = new frmproductsearch();
				producFrmproductsearch.frame.setVisible(true);
				frame.dispose();
			}
		});
		btnSearchAllProduct.setForeground(Color.ORANGE);
		btnSearchAllProduct.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnSearchAllProduct.setBounds(636, 95, 247, 33);
		frame.getContentPane().add(btnSearchAllProduct);
		FetchRecordCategoryID();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Product");
		frame.setBounds(100, 100, 897, 432);
		frame.setLocationRelativeTo(null);
		frame.setUndecorated(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Panel panel = new Panel();
		panel.setBackground(Color.GRAY);
		panel.setBounds(0, 0, 897, 76);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PRODUCT");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(366, 11, 180, 54);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Product ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(47, 139, 95, 33);
		frame.getContentPane().add(lblNewLabel_1);
		
		txtproid = new JTextField();
		txtproid.setBounds(152, 140, 181, 33);
		frame.getContentPane().add(txtproid);
		txtproid.setColumns(10);
		
		txtproname = new JTextField();
		txtproname.setColumns(10);
		txtproname.setBounds(152, 196, 181, 33);
		frame.getContentPane().add(txtproname);
		
		JLabel lblNewLabel_1_1 = new JLabel("Product Name");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(47, 195, 95, 33);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		scrollPane.setBounds(364, 139, 519, 192);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		table.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.setShowGrid(false);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtproid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				txtproname.setText(tModel.getValueAt(table.getSelectedRow(),1).toString());
			}
		});
		scrollPane.setViewportView(table);		
		JLabel lblNewLabel_1_1_1 = new JLabel("Category Name");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1_1_1.setBounds(10, 239, 132, 33);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		JButton btnNewButton = new JButton("Add New Product");
		btnNewButton.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_product_30px.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				FetchData();
				ClearData();				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnNewButton.setBounds(115, 342, 203, 33);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateData();
				FetchData();
				ClearData();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_update_30px.png"));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnNewButton_1.setBounds(364, 342, 68, 33);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteData();
				FetchData();
				ClearData();
				
			}
		});
		btnNewButton_1_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_delete_30px.png"));
		btnNewButton_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnNewButton_1_1.setBounds(442, 342, 68, 33);
		frame.getContentPane().add(btnNewButton_1_1);
		
	
		comboBox.setBounds(152, 239, 181, 33);
		frame.getContentPane().add(comboBox);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sqString = "Select * from tblcategory where categoryname=?";
					sdb.pt = sdb.connection.prepareStatement(sqString);
					sdb.pt.setString(1, (String)comboBox.getSelectedItem());
					sdb.rs =sdb.pt.executeQuery();
					while (sdb.rs.next()) {
						txtcategoryid.setText(sdb.rs.getString("categoryid"));
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
			}
		});
		
		JLabel lblNewLabel_1_2 = new JLabel("Category ID");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(47, 281, 95, 33);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		txtcategoryid = new JTextField();
		
		txtcategoryid.setForeground(Color.RED);
		txtcategoryid.setEnabled(false);
		txtcategoryid.setColumns(10);
		txtcategoryid.setBounds(152, 282, 181, 33);
		frame.getContentPane().add(txtcategoryid);
	}

	
	public void FetchRecordCategoryID() {
		try {
			String queryString = "select * from tblcategory";
			sdb.st = sdb.connection.createStatement();
			sdb.rs = sdb.st.executeQuery(queryString);
			while (sdb.rs.next()) {
				comboBox.addItem(sdb.rs.getString("categoryname"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		sdb.Displaydb("Select * from tblproduct");
		table.setModel(DbUtils.resultSetToTableModel(sdb.rs));
	}

	@Override
	public void InsertData() {
		// TODO Auto-generated method stub
		String productid = txtproid.getText();
		String productname= txtproname.getText();
		if(productid.equals("") && productname.equals("")) {
			JOptionPane.showMessageDialog(null, "Please Complate Information Product!");
			return;
		}
		//Check Validate Record Duplicate
		try {
			sdb.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			String sql = "Select * from tblproduct where productid='"+txtproid.getText()+"'";
			sdb.st = sdb.connection.createStatement();
			sdb.rs = sdb.st.executeQuery(sql);
			if(sdb.rs.next() == true) {
				JOptionPane.showMessageDialog(null, "Record Extist !");
				return;
			}else {
				
				sdb.SpecialRecord("Insert into tblproduct values('"+txtproid.getText()+"' , '"+txtproname.getText()+"','"+txtcategoryid.getText()+"')");
				JOptionPane.showMessageDialog(null, "Product save Successfully !" , "Recorde Save" , JOptionPane.INFORMATION_MESSAGE);	
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub		
		try {
			if(JOptionPane.showConfirmDialog(null, "Do You Want To Update Product ?") == 0) {
				sdb.SpecialRecord("Update tblproduct set productname='"+txtproname.getText()+"',categoryid='"+txtcategoryid.getText()+"' where productid='"+txtproid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Product Update Successfully !" , "Recorde Update" , JOptionPane.INFORMATION_MESSAGE);
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void DeleteData()   {
		// TODO Auto-generated method stub
		
		
			try {
					if(JOptionPane.showConfirmDialog(null, "Do You Want To Delete Product ?") == 0) {
					sdb.Displaydb("Delete from tblproduct where productid='"+txtproid.getText()+"'");
					JOptionPane.showMessageDialog(null, "Product Delete Successfully !" , "Recorde Delete" , JOptionPane.INFORMATION_MESSAGE);
					}
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
		
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		txtproid.setText("");
		txtproname.setText("");
		comboBox.setSelectedIndex(0);
		txtcategoryid.setText("");
	}
}
