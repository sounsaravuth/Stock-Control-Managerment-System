package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmviewallstock implements IDatabase {

	 JFrame framestockviewall;
	private JTable tablestockin;
	private JTable tablestockout;
	stockdb stockdbs = new stockdb();
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmviewallstock window = new frmviewallstock();
					window.framestockviewall.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmviewallstock() {
		initialize();
		stockdbs.DatabaseConnection();
		FetchData();
		InsertData();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		framestockviewall = new JFrame();
		framestockviewall.setBounds(100, 100, 1311, 882);
		framestockviewall.setLocationRelativeTo(null);
		framestockviewall.setUndecorated( true );
		framestockviewall.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		framestockviewall.getContentPane().setLayout(null);
		scrollPane = new JScrollPane();
		scrollPane.setBounds(98, 112, 1125, 302);
		framestockviewall.getContentPane().add(scrollPane);	
		tablestockin = new JTable();
		tablestockin.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)tablestockin.getDefaultRenderer(Object.class);
	      renderer.setHorizontalAlignment( SwingConstants.CENTER );
	      tablestockin.setShowGrid(false);
		scrollPane.setViewportView(tablestockin);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(98, 513, 1125, 302);
		framestockviewall.getContentPane().add(scrollPane_1);
		
		tablestockout = new JTable();
		tablestockout.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer1 = (DefaultTableCellRenderer)tablestockout.getDefaultRenderer(Object.class);
	      renderer1.setHorizontalAlignment( SwingConstants.CENTER );
	      tablestockout.setShowGrid(false);
		scrollPane_1.setViewportView(tablestockout);
		
		JLabel lblNewLabel = new JLabel("StockOut");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(95, 454, 1128, 42);
		framestockviewall.getContentPane().add(lblNewLabel);
		
		JLabel lblStockin = new JLabel("StockIn");
		lblStockin.setHorizontalAlignment(SwingConstants.CENTER);
		lblStockin.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblStockin.setBounds(95, 57, 1128, 42);
		framestockviewall.getContentPane().add(lblStockin);
		
		JButton btnNewButton = new JButton("Back To Menu");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain main = new frmMain();
				main.MainFram.setVisible(true);
				framestockviewall.dispose();
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(543, 826, 257, 45);
		framestockviewall.getContentPane().add(btnNewButton);
	}

	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblstockin");
		tablestockin.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void InsertData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblstockout");
		tablestockout.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		
	}
}
