package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import com.toedter.calendar.JDateChooser;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class frmstockin implements IDatabase {

	 JFrame framestockin;
	private JTextField txtstockid;
	private JTextField txtqty;
	private JTextField txtunitcost;
	private JTextField txtsupplierid;
	private JTextField txtproid;
	private JTextField txtdeleveryid;
	private JTable table;
	private JTextField txtsearch;
	JDateChooser txtdate = new JDateChooser();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String date = sdf.format(txtdate.getDate());
	JComboBox<String> cbodeliveryno = new JComboBox<String>();
	JComboBox<String> cboproname = new JComboBox<String>();
	JComboBox <String>cbosuppliername = new JComboBox<String>();
	stockdb stockdbs= new stockdb();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmstockin window = new frmstockin();
					window.framestockin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmstockin() {
		initialize();
		stockdbs.DatabaseConnection();
		FetchData();
		FetchRecordSupplierid();
		FetchRecordProductid(null);
		FetchRecorddeliveryid(null);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		framestockin = new JFrame();
		framestockin.setBounds(100, 100, 1537, 714);
		framestockin.setLocationRelativeTo(null);
		framestockin.setUndecorated(true);
		framestockin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		framestockin.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1537, 65);
		framestockin.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Stock In");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(630, 11, 298, 43);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1.setBounds(1014, 76, 497, 588);
		framestockin.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Stock ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(41, 121, 72, 25);
		panel_1.add(lblNewLabel_1);
		
		txtstockid = new JTextField();
		txtstockid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtstockid.setBounds(123, 120, 163, 28);
		panel_1.add(txtstockid);
		txtstockid.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Date In");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(41, 157, 72, 25);
		panel_1.add(lblNewLabel_1_1);
		
		JDateChooser txtdate = new JDateChooser();
		txtdate.getSpinner().setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtdate.setBounds(123, 157, 163, 30);
		panel_1.add(txtdate);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Qty");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(41, 194, 72, 25);
		panel_1.add(lblNewLabel_1_1_1);
		
		txtqty = new JTextField();
		txtqty.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtqty.setColumns(10);
		txtqty.setBounds(123, 193, 163, 28);
		panel_1.add(txtqty);
		
		txtunitcost = new JTextField();
		txtunitcost.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtunitcost.setColumns(10);
		txtunitcost.setBounds(123, 232, 163, 28);
		panel_1.add(txtunitcost);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("UnitiCost");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(41, 233, 72, 25);
		panel_1.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Supplier Name");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1.setBounds(10, 269, 103, 25);
		panel_1.add(lblNewLabel_1_1_1_1_1);
		cbosuppliername.setModel(new DefaultComboBoxModel(new String[] {"Select Supplier Name"}));
		cbosuppliername.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "Select * from tblsupplier where suppliername=?";
					stockdbs.pt = stockdbs.connection.prepareStatement(sql);	
					stockdbs.pt.setString(1, (String)cbosuppliername.getSelectedItem());
					stockdbs.rs = stockdbs.pt.executeQuery();
					while (stockdbs.rs.next()) {
						txtsupplierid.setText(stockdbs.rs.getString("supplierid"));						
					}
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2);
				}
			}
		});
		
	
		cbosuppliername.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		cbosuppliername.setBounds(123, 271, 163, 23);
		panel_1.add(cbosuppliername);
		
		txtsupplierid = new JTextField();
		txtsupplierid.setForeground(Color.RED);
		txtsupplierid.setEnabled(false);
		txtsupplierid.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtsupplierid.setColumns(10);
		txtsupplierid.setBounds(123, 302, 163, 28);
		panel_1.add(txtsupplierid);
		
		JLabel lblNewLabel_1_2 = new JLabel("Supplier ID");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(41, 305, 72, 25);
		panel_1.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Product Name");
		lblNewLabel_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1_1.setBounds(12, 341, 103, 25);
		panel_1.add(lblNewLabel_1_1_1_1_1_1);
		
		cboproname.setModel(new DefaultComboBoxModel(new String[] {"Select Product Name"}));
		cboproname.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					String sqlString = "Select * from tblproduct where productname=?";
					stockdbs.pt = stockdbs.connection.prepareStatement(sqlString);
					stockdbs.pt.setString(1, (String)cboproname.getSelectedItem());
					stockdbs.rs =stockdbs.pt.executeQuery();
					while (stockdbs.rs.next()) {
						txtproid.setText(stockdbs.rs.getString("productid"));
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
			
		});
		
		cboproname.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		cboproname.setBounds(123, 342, 163, 23);
		panel_1.add(cboproname);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Product ID");
		lblNewLabel_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_2_1.setBounds(41, 378, 72, 25);
		panel_1.add(lblNewLabel_1_2_1);
		
		txtproid = new JTextField();
		txtproid.setForeground(Color.RED);
		txtproid.setEnabled(false);
		txtproid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtproid.setColumns(10);
		txtproid.setBounds(123, 375, 163, 28);
		panel_1.add(txtproid);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("Delivery no");
		lblNewLabel_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_2_1_1.setBounds(41, 416, 72, 25);
		panel_1.add(lblNewLabel_1_2_1_1);
		cbodeliveryno.setModel(new DefaultComboBoxModel <String>(new String[] {"Select Delivery No"}));
		cbodeliveryno.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
					try {
						String sqString = "Select * from tbldelivery where deliveryno=?";
						stockdbs.pt = stockdbs.connection.prepareStatement(sqString);
						stockdbs.pt.setString(1, (String)cbodeliveryno.getSelectedItem());
						stockdbs.rs =stockdbs.pt.executeQuery();
						while (stockdbs.rs.next()) {
							txtdeleveryid.setText(stockdbs.rs.getString("deliveryid"));
						}
					} catch (Exception e2) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, e2);
					}
			}
			
		});
		
		cbodeliveryno.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		cbodeliveryno.setBounds(123, 416, 163, 23);
		panel_1.add(cbodeliveryno);
		
		txtdeleveryid = new JTextField();
		txtdeleveryid.setForeground(Color.RED);
		txtdeleveryid.setEnabled(false);
		txtdeleveryid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtdeleveryid.setColumns(10);
		txtdeleveryid.setBounds(123, 450, 163, 28);
		panel_1.add(txtdeleveryid);
		
		JLabel lblNewLabel_1_2_1_2 = new JLabel("Delievery ID");
		lblNewLabel_1_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_2_1_2.setBounds(41, 453, 72, 25);
		panel_1.add(lblNewLabel_1_2_1_2);
		
		JButton btnNewButton = new JButton("Delete Stock");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteData();
				FetchData();
				ClearData();
			}
		});
		btnNewButton.setBounds(123, 489, 170, 30);
		panel_1.add(btnNewButton);
		
		JButton btnUpdateNewStock = new JButton("Update New stock");
		btnUpdateNewStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateData();
				FetchData();
				ClearData();
			}
		});
		btnUpdateNewStock.setBounds(123, 530, 170, 30);
		panel_1.add(btnUpdateNewStock);
		
		JButton btnAddNewStock = new JButton("Add New Stock");
		btnAddNewStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				FetchData();
				ClearData();
			}
		});
		btnAddNewStock.setBounds(296, 119, 170, 30);
		panel_1.add(btnAddNewStock);
		
		JLabel lblNewLabel_2 = new JLabel("Stock In");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_2.setBounds(132, 41, 298, 43);
		panel_1.add(lblNewLabel_2);
		
		JButton btnBackToMenu = new JButton("Back To Menu");
		btnBackToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain main = new frmMain();
				main.MainFram.setVisible(true);
				framestockin.dispose();
			}
		});
		btnBackToMenu.setBounds(296, 159, 170, 30);
		panel_1.add(btnBackToMenu);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 202, 994, 462);
		framestockin.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtstockid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				try {
					Date dates = (Date) new SimpleDateFormat("yyyy-MM-dd").parse((String)tModel.getValueAt(table.getSelectedRow(), 1).toString());
					txtdate.setDate(dates);
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, e2);
				}
				txtqty.setText(tModel.getValueAt(table.getSelectedRow(),2).toString());
				txtunitcost.setText(tModel.getValueAt(table.getSelectedRow(),3).toString());
				txtsupplierid.setText(tModel.getValueAt(table.getSelectedRow(),4).toString());
				txtproid.setText(tModel.getValueAt(table.getSelectedRow(),5).toString());
				txtdeleveryid.setText(tModel.getValueAt(table.getSelectedRow(),6).toString());
				
			}
		});
		scrollPane.setViewportView(table);
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		table.setShowGrid(false);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "SEARCH RECORD", TitledBorder.CENTER, TitledBorder.TOP, null, Color.RED));
		panel_2.setBounds(10, 126, 994, 65);
		framestockin.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		txtsearch = new JTextField();
		txtsearch.setBounds(10, 22, 974, 32);
		panel_2.add(txtsearch);
		txtsearch.setColumns(10);
	}

	
	public void FetchRecordSupplierid() {
		try {
			String sql= "select * from tblsupplier";
			stockdbs.st = stockdbs.connection.createStatement();			
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			while (stockdbs.rs.next()) {
				cbosuppliername.addItem(stockdbs.rs.getString("suppliername"));
			}
			} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public void FetchRecordProductid(String sql) {
		try {
			String queryString = "select * from tblproduct";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(queryString);
			while (stockdbs.rs.next()) {
				cboproname.addItem(stockdbs.rs.getString("productname"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void FetchRecorddeliveryid(String sql) {
		try {
			String queryString = "select * from tbldelivery";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(queryString);
			while (stockdbs.rs.next()) {
				cbodeliveryno.addItem(stockdbs.rs.getString("deliveryno"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblstockin");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void InsertData() {
		String stockidString = txtstockid.getText();
		int qty = 0;
		
		// TODO Auto-generated method stub
		if(stockidString.equals("") ) {
			JOptionPane.showMessageDialog(null, "Please Fill Information !","Warning",JOptionPane.WARNING_MESSAGE);
			return;
		}
		if(qty != 0) {
			JOptionPane.showMessageDialog(null, "Stock Empty Please Add More Stock ! " , "Stock Empty" , JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		try {
			stockdbs.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			String sql = "select * from tblstockin where stockinid='"+txtstockid.getText()+"'";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			if(stockdbs.rs.next() == true) {
				JOptionPane.showMessageDialog(null, "Record Extist '"+txtstockid.getText()+"'! "+txtstockid.getText()+"'!" , "Warning" , JOptionPane.WARNING_MESSAGE);
				return;
			}		
			stockdbs.SpecialRecord("Insert Into tblstockin values('"+txtstockid.getText()+"','"+date+"','"+txtqty.getText()+"','"+txtunitcost.getText()+"','"+txtsupplierid.getText()+"','"+txtproid.getText()+"','"+txtdeleveryid.getText()+"')");
			JOptionPane.showMessageDialog(null, "Record Stock In Add New  !'"+txtstockid.getText()+"'" ,"Record Save",JOptionPane.INFORMATION_MESSAGE);
			
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Update Stock In Record ?","Question",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Update tblstockin set Datein='"+date+"',quantityin='"+txtqty.getText()+"',unitcost='"+txtunitcost.getText()+"',supplierid='"+txtsupplierid.getText()+"',productid='"+txtproid.getText()+"',deliveryid='"+txtdeleveryid.getText()+"' where stockinid='"+txtstockid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Stock In Update  !'"+txtstockid.getText()+"'" ,"Record Save",JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
		}
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Delete Stock In Record ?","Question",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.ERROR_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Delete from tblstockin where stockinid='"+txtstockid.getText()+"'");
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
		}
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
			txtstockid.setText("");
			txtqty.setText("");
			txtunitcost.setText("");
			txtsupplierid.setText("");
			txtproid.setText("");
			txtdeleveryid.setText("");
			cbosuppliername.setSelectedIndex(0);
			cbodeliveryno.setSelectedIndex(0);
			cboproname.setSelectedIndex(0);
	}
}
