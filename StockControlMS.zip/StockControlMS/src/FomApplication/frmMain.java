package FomApplication;

import java.awt.EventQueue;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Timer;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.event.AncestorListener;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import rojerusan.RSButtonPane;
import rojerusan.RSButtonRound;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class frmMain {

	JFrame MainFram;
	JLabel lbldate = new JLabel("Date");
	/**
	 * Launch the application.
	 */
	public static  void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmMain window = new frmMain();
					window.MainFram.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmMain() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		MainFram = new JFrame();
		MainFram.setBounds(100, 100, 1425, 776);
		MainFram.setLocationRelativeTo(null);
		MainFram.setUndecorated( true );
		MainFram.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MainFram.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel.setBounds(54, 74, 306, 255);
		MainFram.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_teamwork_100px.png"));
		lblNewLabel.setBounds(0, 11, 306, 144);
		panel.add(lblNewLabel);
		
		RSButtonRound btnrndEmployee = new RSButtonRound();
		btnrndEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmstaff fm = new frmstaff();
				fm.staffframe.setVisible(true);
				MainFram.dispose();
			}
		});
		
		btnrndEmployee.setText("EMPLOYEE");
		btnrndEmployee.setBounds(10, 166, 286, 64);
		panel.add(btnrndEmployee);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(370, 74, 333, 255);
		MainFram.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_supplier_100px.png"));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 11, 313, 161);
		panel_1.add(lblNewLabel_1);
		
		RSButtonRound btnrndSupplier = new RSButtonRound();
		btnrndSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmsupplier fsuppFrmsupplier = new frmsupplier();
				fsuppFrmsupplier.supplierframe.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndSupplier.setText("SUPPLIER");
		btnrndSupplier.setBounds(16, 164, 307, 64);
		panel_1.add(btnrndSupplier);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(713, 74, 333, 255);
		MainFram.getContentPane().add(panel_2);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_product_100px.png"));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(10, 11, 313, 155);
		panel_2.add(lblNewLabel_2);
		
		RSButtonRound btnrndProduct = new RSButtonRound();
		btnrndProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmproduct fproduct = new frmproduct();
				fproduct.frame.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndProduct.setText("PRODUCT");
		btnrndProduct.setBounds(16, 166, 307, 64);
		panel_2.add(btnrndProduct);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(1056, 74, 320, 255);
		MainFram.getContentPane().add(panel_3);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_scan_stock_100px.png"));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(10, 11, 300, 157);
		panel_3.add(lblNewLabel_3);
		
		RSButtonRound btnrndStockIn = new RSButtonRound();
		btnrndStockIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmstockin stockin =  new frmstockin();
				stockin.framestockin.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndStockIn.setText("STOCK IN");
		btnrndStockIn.setBounds(10, 168, 307, 64);
		panel_3.add(btnrndStockIn);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1_1.setBackground(Color.WHITE);
		panel_1_1.setBounds(33, 340, 306, 247);
		MainFram.getContentPane().add(panel_1_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_scan_stock_100px.png"));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(29, 11, 248, 146);
		panel_1_1.add(lblNewLabel_1_1);
		
		RSButtonRound btnrndStockOut = new RSButtonRound();
		btnrndStockOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmstockout stockout = new frmstockout();
				stockout.framestockout.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndStockOut.setText("STOCK OUT");
		btnrndStockOut.setBounds(20, 168, 272, 61);
		panel_1_1.add(btnrndStockOut);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setLayout(null);
		panel_1_2.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1_2.setBackground(Color.WHITE);
		panel_1_2.setBounds(349, 340, 320, 247);
		MainFram.getContentPane().add(panel_1_2);
		
		JLabel lblNewLabel_1_2 = new JLabel("");
		lblNewLabel_1_2.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_Delivery_100px.png"));
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setBounds(23, 17, 272, 139);
		panel_1_2.add(lblNewLabel_1_2);
		
		RSButtonRound btnrndDelivery = new RSButtonRound();
		btnrndDelivery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmdelivery delivery = new frmdelivery();
				delivery.frameDelivery.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndDelivery.setText("DELIVERY");
		btnrndDelivery.setBounds(10, 167, 307, 64);
		panel_1_2.add(btnrndDelivery);
		
		JPanel panel_1_3 = new JPanel();
		panel_1_3.setLayout(null);
		panel_1_3.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1_3.setBackground(Color.WHITE);
		panel_1_3.setBounds(679, 340, 333, 247);
		MainFram.getContentPane().add(panel_1_3);
		
		JLabel lblNewLabel_1_3 = new JLabel("");
		lblNewLabel_1_3.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_report_file_100px.png"));
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setBounds(35, 13, 263, 141);
		panel_1_3.add(lblNewLabel_1_3);
		
		RSButtonRound btnrndSupplier_1 = new RSButtonRound();
		btnrndSupplier_1.setText("REPORT");
		btnrndSupplier_1.setBounds(16, 164, 307, 64);
		panel_1_3.add(btnrndSupplier_1);
		
		JPanel panel_1_4 = new JPanel();
		panel_1_4.setLayout(null);
		panel_1_4.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1_4.setBackground(Color.WHITE);
		panel_1_4.setBounds(1022, 340, 333, 247);
		MainFram.getContentPane().add(panel_1_4);
		
		JLabel lblNewLabel_1_4 = new JLabel("");
		lblNewLabel_1_4.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_purchase_order_100px.png"));
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setBounds(37, 11, 251, 135);
		panel_1_4.add(lblNewLabel_1_4);
		
		RSButtonRound btnrndPurchase = new RSButtonRound();
		btnrndPurchase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmpurchaseorder purchaseorder = new frmpurchaseorder();
				purchaseorder.frame.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndPurchase.setText("PURCHASE");
		btnrndPurchase.setBounds(16, 165, 307, 64);
		panel_1_4.add(btnrndPurchase);
		lbldate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		
		//JLabel lbldate = new JLabel("Date");
		lbldate.setBounds(1098, 5, 277, 58);
		MainFram.getContentPane().add(lbldate);
		
		JLabel lblNewLabel_4 = new JLabel("STOCK CONTROL MANAGERMENT SYSTEM");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 28));
		lblNewLabel_4.setBounds(370, 11, 647, 52);
		MainFram.getContentPane().add(lblNewLabel_4);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.WHITE);
		panel_4.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_4.setBounds(33, 598, 339, 167);
		MainFram.getContentPane().add(panel_4);
		panel_4.setLayout(null);		
		JLabel lblNewLabel_1_1_1 = new JLabel("");
		lblNewLabel_1_1_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_invoice_100px.png"));
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setBounds(23, 11, 286, 92);
		panel_4.add(lblNewLabel_1_1_1);		
		RSButtonRound btnrndInvoice = new RSButtonRound();
		btnrndInvoice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frminvoice iFrminvoice = new frminvoice();
				iFrminvoice.frameinvoice.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndInvoice.setText("INVOICE");
		btnrndInvoice.setBounds(46, 106, 252, 50);
		panel_4.add(btnrndInvoice);
		
		JPanel panel_4_1 = new JPanel();
		panel_4_1.setLayout(null);
		panel_4_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_4_1.setBackground(Color.WHITE);
		panel_4_1.setBounds(751, 598, 339, 167);
		MainFram.getContentPane().add(panel_4_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("");
		lblNewLabel_1_1_1_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_Logout_100px.png"));
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1.setBounds(23, 11, 286, 92);
		panel_4_1.add(lblNewLabel_1_1_1_1);
		
		RSButtonRound btnrndExitToMenu = new RSButtonRound();
		btnrndExitToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmlogin logins = new frmlogin();
				logins.Loginfram.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndExitToMenu.setText("Exit To Menu\r\n");
		btnrndExitToMenu.setBounds(46, 106, 252, 50);
		panel_4_1.add(btnrndExitToMenu);
		
		JPanel panel_4_1_1 = new JPanel();
		panel_4_1_1.setLayout(null);
		panel_4_1_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_4_1_1.setBackground(Color.WHITE);
		panel_4_1_1.setBounds(388, 598, 339, 167);
		MainFram.getContentPane().add(panel_4_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("");
		lblNewLabel_1_1_1_1_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_scan_stock_100px.png"));
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1_1.setBounds(23, 11, 286, 92);
		panel_4_1_1.add(lblNewLabel_1_1_1_1_1);
		
		RSButtonRound btnrndViewAllStock = new RSButtonRound();
		btnrndViewAllStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmviewallstock viewallstock = new frmviewallstock();
				viewallstock.framestockviewall.setVisible(true);
				MainFram.dispose();
			}
		});
		btnrndViewAllStock.setText("View All Stock");
		btnrndViewAllStock.setBounds(46, 106, 252, 50);
		panel_4_1_1.add(btnrndViewAllStock);
	}	
	public void clock() {
		try {
			Calendar cal = new GregorianCalendar();
			int day = cal.get(Calendar.DAY_OF_MONTH);
			int month = cal.get(Calendar.MONTH);
			int year = cal.get(Calendar.YEAR);
			int second = cal.get(Calendar.SECOND);
			int minute = cal.get(Calendar.MINUTE);
			int hour = cal.get(Calendar.HOUR);
			lbldate.setText("Time"+hour+":"+minute+":"+second+" Date"+year+"/"+month+"/"+day);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
