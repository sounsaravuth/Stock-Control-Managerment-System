package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;


import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JPasswordField;


public class frmlogin  {
	//Declare Variable
	
	JFrame Loginfram;
	private JTextField txtUsername;
	private JPasswordField passwordField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmlogin window = new frmlogin();
					window.Loginfram.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	public frmlogin() {
		initialize();
		
		
		JLabel lblNewLabel_3 = new JLabel("SYSTEM DEVELOPER VERSON 1.0");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(525, 431, 219, 14);
		Loginfram.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_1 = new JLabel("UserName");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_1.setBounds(444, 83, 121, 38);
		Loginfram.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_1_1.setBounds(444, 180, 121, 38);
		Loginfram.getContentPane().add(lblNewLabel_1_1);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_enter_30px.png"));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(423, 283, 150, 37);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				String username = txtUsername.getText();
				@SuppressWarnings("deprecation")
				String Password = passwordField.getText();
				
				if(username.equals("Admin") && Password.equals("1122")) {
					frmMain main = new frmMain();
					main.MainFram.setVisible(true);
					Loginfram.dispose();
				}else {
					JOptionPane.showMessageDialog(null, "You Can't Login Please Check UserName And Password" ,"Validate",JOptionPane.ERROR_MESSAGE);
				}
				
				
				
				
			}
			
		});
		Loginfram.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnExit.setBounds(594, 283, 150, 37);
		Loginfram.getContentPane().add(btnExit);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(444, 235, 273, 37);
		Loginfram.getContentPane().add(passwordField);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Loginfram = new JFrame("Login");
		Loginfram.setResizable(false);
		Loginfram.getContentPane().setBackground(Color.LIGHT_GRAY);
		Loginfram.setBounds(100, 100, 756, 456);		
		Loginfram.setLocationRelativeTo(null);
		Loginfram.setUndecorated(true);
	
		Loginfram.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Loginfram.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 413, 456);
		Loginfram.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\retail-and-consumer-goods-mobile.gif"));
		lblNewLabel.setBounds(10, 11, 393, 434);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Sign in");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(540, 26, 121, 46);
		Loginfram.getContentPane().add(lblNewLabel_1);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtUsername.setHorizontalAlignment(SwingConstants.LEFT);
		txtUsername.setBounds(444, 138, 273, 31);
		Loginfram.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
	}
	
	
}
