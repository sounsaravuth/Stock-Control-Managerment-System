package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Set;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class frmquote implements IDatabase {

	private JFrame frame;
	private JTextField txtsupplierid;
	private JTextField txtquoteid;
	private JTextField txtquoteno;
	private JTextField txtquotevalue;
	stockdb stockdbs = new stockdb();
	JComboBox<String> cbosuppliername = new JComboBox<String>();
	private JTable table;
	private JTextField txtsearch;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmquote window = new frmquote();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmquote() {
		initialize();
	
		stockdbs.DatabaseConnection();
		FetchRecordsupplier();
		FetchData();
	}	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1237, 581);
		frame.setLocationRelativeTo(null);
		frame.setUndecorated(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1221, 83);
		frame.getContentPane().add(panel);
		
		JLabel lblQuote = new JLabel("QUOTE");
		lblQuote.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuote.setForeground(Color.WHITE);
		lblQuote.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblQuote.setBounds(357, 11, 501, 61);
		panel.add(lblQuote);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(10, 11, 108, 61);
		panel.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(new TitledBorder(null, "SEARCH ", TitledBorder.LEADING, TitledBorder.TOP, null, Color.RED));
		panel_2.setBounds(10, 84, 804, 51);
		frame.getContentPane().add(panel_2);
		
		txtsearch = new JTextField();
		txtsearch.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtsearch.setColumns(10);
		txtsearch.setBounds(66, 11, 686, 34);
		panel_2.add(txtsearch);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1.setBounds(835, 134, 376, 397);
		frame.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Supplier ID");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 65, 103, 27);
		panel_1.add(lblNewLabel_2);
		
		txtsupplierid = new JTextField();
		txtsupplierid.setEnabled(false);
		txtsupplierid.setFont(new Font("Times New Roman", Font.BOLD, 18));
		txtsupplierid.setColumns(10);
		txtsupplierid.setBounds(123, 62, 232, 34);
		panel_1.add(txtsupplierid);
		
		JLabel lblNewLabel_2_1 = new JLabel("Quote ID");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_1.setBounds(10, 110, 103, 27);
		panel_1.add(lblNewLabel_2_1);
		
		txtquoteid = new JTextField();
		txtquoteid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtquoteid.setColumns(10);
		txtquoteid.setBounds(123, 107, 232, 34);
		panel_1.add(txtquoteid);
		
		JLabel lblNewLabel_2_2 = new JLabel("Quote No");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_2.setBounds(10, 160, 103, 27);
		panel_1.add(lblNewLabel_2_2);
		
		txtquoteno = new JTextField();
		txtquoteno.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtquoteno.setColumns(10);
		txtquoteno.setBounds(123, 157, 232, 34);
		panel_1.add(txtquoteno);
		
		JButton btnAddNewQuote = new JButton("ADD NEW QUOTE");
		btnAddNewQuote.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				FetchData();
				ClearData();
			}
			
		});
		btnAddNewQuote.setBounds(123, 293, 232, 34);
		panel_1.add(btnAddNewQuote);
		
		txtquotevalue = new JTextField();
		txtquotevalue.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtquotevalue.setColumns(10);
		txtquotevalue.setBounds(123, 202, 232, 34);
		panel_1.add(txtquotevalue);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Quote value");
		lblNewLabel_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_2_1.setBounds(10, 213, 103, 27);
		panel_1.add(lblNewLabel_2_2_1);
		
		JButton btnUpdateQuote = new JButton("UPDATE QUOTE");
		btnUpdateQuote.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_update_30px.png"));
		btnUpdateQuote.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				UpdateData();
				FetchData();
				ClearData();
			}
			
		});
		btnUpdateQuote.setBounds(123, 338, 232, 34);
		panel_1.add(btnUpdateQuote);
		
		JButton btnUpdateSupplier_1 = new JButton("");
		btnUpdateSupplier_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					DeleteData();
					FetchData();
					ClearData();
			}
		});
		btnUpdateSupplier_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\src\\Image\\icons8_trash_30px.png"));
		btnUpdateSupplier_1.setBounds(27, 298, 86, 74);
		panel_1.add(btnUpdateSupplier_1);
		cbosuppliername.setModel(new DefaultComboBoxModel<String>(new String[] {"Choose"}));
		cbosuppliername.setSelectedIndex(0);
		
		
		cbosuppliername.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "Select * from tblsupplier where suppliername=?";
					stockdbs.pt = stockdbs.connection.prepareStatement(sql);	
					stockdbs.pt.setString(1, (String)cbosuppliername.getSelectedItem());
					stockdbs.rs = stockdbs.pt.executeQuery();
					while (stockdbs.rs.next()) {
						txtsupplierid.setText(stockdbs.rs.getString("supplierid"));						
					}
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, e2);
				}
			}
		});
		
		cbosuppliername.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		
		cbosuppliername.setBounds(124, 11, 231, 34);
		panel_1.add(cbosuppliername);
		
		JLabel lblNewLabel_2_4 = new JLabel("Supplier Name");
		lblNewLabel_2_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_4.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2_4.setBounds(10, 18, 103, 27);
		panel_1.add(lblNewLabel_2_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 146, 793, 385);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtquoteid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				txtquoteno.setText(tModel.getValueAt(table.getSelectedRow(),1).toString());
				txtquotevalue.setText(tModel.getValueAt(table.getSelectedRow(),2).toString());
				txtsupplierid.setText(tModel.getValueAt(table.getSelectedRow(),3).toString());
			}
		});
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.setShowGrid(false);
		scrollPane.setViewportView(table);
		
	}
	
	public void FetchRecordsupplier() {
		try {
			String sql = "select * from tblsupplier";
			stockdbs.st = stockdbs.connection.createStatement();			
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			while (stockdbs.rs.next()) {
				cbosuppliername.addItem(stockdbs.rs.getString("suppliername"));
			}
		} catch (Exception e2) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e2);
		}
	
	}
	
	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("Select * from tblquote");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void InsertData() {
			String supplierid = txtsupplierid.getText();
			String quoteid = txtquoteid.getText();
			String quoteno = txtquoteno.getText();
		 	String quotevalue = txtquotevalue.getText();
		// TODO Auto-generated method stub
		 	if(quoteid.equals("") && quoteno.equals("") && supplierid.equals("") && quotevalue.equals("")) {
				JOptionPane.showMessageDialog(null, "Please Fill Information","Warning",JOptionPane.WARNING_MESSAGE);
				return;
			}
		 	
		try {
			stockdbs.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			String sql = "select * from tblquote where quoteid='"+txtquoteid.getText()+"'";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(sql);
			if(stockdbs.rs.next() == true) {
				JOptionPane.showMessageDialog(null, "Record Extist !" , "Warning" , JOptionPane.WARNING_MESSAGE);
				return;
			}else {
				stockdbs.SpecialRecord("insert into tblquote values ('"+txtquoteid.getText()+"','"+txtquoteno.getText()+"','"+txtquotevalue.getText()+"','"+txtsupplierid.getText()+"')");
				JOptionPane.showMessageDialog(null, "Record Quote Save !" , "Record save",JOptionPane.INFORMATION_MESSAGE);
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Update Quote Record ?" , "Question",JOptionPane.YES_NO_CANCEL_OPTION ,JOptionPane.QUESTION_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Update tblquote set quoteno='"+txtquoteno.getText()+"',quotevalue='"+txtquotevalue.getText()+"',supplierid='"+txtsupplierid.getText()+"' where quoteid='"+txtquoteid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Quote Update !" , "Record Update",JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
		}
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Delete Quote Record ?" , "Question",JOptionPane.YES_NO_CANCEL_OPTION ,JOptionPane.QUESTION_MESSAGE) == 0) {
			try {
				stockdbs.SpecialRecord("Delete from tblquote where quoteid='"+txtquoteid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Quote Delete !" , "Record Delete",JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e);
			}
		}
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		txtsupplierid.setText("");
		txtquoteno.setText("");
		txtquotevalue.setText("");
		txtquoteid.setText("");
		cbosuppliername.setSelectedIndex(0);
		
	}
}
