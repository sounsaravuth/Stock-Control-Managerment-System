package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.text.SimpleDateFormat;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import com.toedter.calendar.JDateChooser;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import rojerusan.RSTableMetro;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class frmstockout implements IDatabase {

	 JFrame framestockout;
	private JTextField txtstockoutid;
	private JTextField txtqtyout;
	private JTextField textField_6;
	JComboBox<String> cbostockid = new JComboBox<String>();
	stockdb stockdbs = new stockdb();
	JDateChooser txtdate = new JDateChooser();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String date = sdf.format(txtdate.getDate());
	private JTable table;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmstockout window = new frmstockout();
					window.framestockout.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmstockout() {
		initialize();
		stockdbs.DatabaseConnection();
		cbostockid.addItem("Select StockIn ID");
		cbostockid.setSelectedIndex(0);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(533, 223, 978, 430);
		framestockout.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		table.setShowGrid(false);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtstockoutid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				txtqtyout.setText(tModel.getValueAt(table.getSelectedRow(),2).toString());
				cbostockid.setSelectedItem(tModel.getValueAt(table.getSelectedRow(),3).toString());
			}
		});
		scrollPane.setViewportView(table);
		FetchData();
		FetchRecordStockinID();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		framestockout = new JFrame();
		framestockout.setBounds(100, 100, 1537, 714);
		framestockout.setLocationRelativeTo(null);
		framestockout.setUndecorated(true);
		framestockout.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		framestockout.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1537, 65);
		framestockout.getContentPane().add(panel);
		
		JLabel lblStockOut = new JLabel("STOCK OUT");
		lblStockOut.setHorizontalAlignment(SwingConstants.CENTER);
		lblStockOut.setForeground(Color.WHITE);
		lblStockOut.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblStockOut.setBounds(630, 11, 298, 43);
		panel.add(lblStockOut);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(UIManager.getBorder("InternalFrame.border"));
		panel_1.setBounds(10, 76, 497, 588);
		framestockout.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("StockOut ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(25, 121, 88, 25);
		panel_1.add(lblNewLabel_1);
		
		txtstockoutid = new JTextField();
		txtstockoutid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtstockoutid.setColumns(10);
		txtstockoutid.setBounds(123, 120, 163, 28);
		panel_1.add(txtstockoutid);
		
		JLabel lblNewLabel_1_1 = new JLabel("Date Out");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(41, 157, 72, 25);
		panel_1.add(lblNewLabel_1_1);
		
		JDateChooser txtdate = new JDateChooser();
		txtdate.getSpinner().setFont(new Font("Times New Roman", Font.PLAIN, 15));
		txtdate.setBounds(123, 157, 163, 30);
		panel_1.add(txtdate);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Qty");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(41, 194, 72, 25);
		panel_1.add(lblNewLabel_1_1_1);
		
		txtqtyout = new JTextField();
		txtqtyout.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtqtyout.setColumns(10);
		txtqtyout.setBounds(123, 193, 163, 28);
		panel_1.add(txtqtyout);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("stockIn ID");
		lblNewLabel_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_1_2_1_1.setBounds(41, 230, 72, 25);
		panel_1.add(lblNewLabel_1_2_1_1);
		
		
		cbostockid.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		cbostockid.setBounds(123, 224, 163, 31);
		panel_1.add(cbostockid);
		
		JButton btnNewButton = new JButton("Revers To StockIn");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteData();
				ClearData();
				FetchData();
			}
		});
		btnNewButton.setBounds(123, 312, 170, 30);
		panel_1.add(btnNewButton);
		
		JButton btnAddNewStock_1 = new JButton("Add Stock out");
		btnAddNewStock_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				ClearData();
				FetchData();
			}
		});
		btnAddNewStock_1.setBounds(123, 271, 170, 30);
		panel_1.add(btnAddNewStock_1);
		
		JLabel lblNewLabel_2 = new JLabel("Stock out");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_2.setBounds(132, 41, 298, 43);
		panel_1.add(lblNewLabel_2);
		
		JButton btnBackToMenu = new JButton("Back To Menu");
		btnBackToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain main = new frmMain();
				main.MainFram.setVisible(true);
				framestockout.dispose();
			}
		});
		btnBackToMenu.setBounds(123, 353, 170, 30);
		panel_1.add(btnBackToMenu);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(new TitledBorder(null, "SEARCH RECORD", TitledBorder.CENTER, TitledBorder.TOP, null, Color.RED));
		panel_2.setBounds(527, 126, 994, 65);
		framestockout.getContentPane().add(panel_2);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(10, 22, 974, 32);
		panel_2.add(textField_6);
	}
	public void FetchRecordStockinID() {
		try {
			String queryString = "select * from tblstockin";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(queryString);
			while (stockdbs.rs.next()) {
				cbostockid.addItem(stockdbs.rs.getString("stockinid"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e);
		}
	}
	@Override
	public void FetchData() {
		try {
			stockdbs.Displaydb("Select * from tblstockout");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

	@Override
	public void InsertData() {
		try {
			stockdbs.SpecialRecord("Insert into tblstockout values('"+txtstockoutid.getText()+"','"+date+"','"+txtqtyout.getText()+"','"+cbostockid.getSelectedItem()+"')");
			JOptionPane.showMessageDialog(null, "Add Stock Out Successfully","Out Stock",JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.SpecialRecord("Delete from tblstockout where stockoutid='"+txtstockoutid.getText()+"'");
			JOptionPane.showMessageDialog(null, "Add Stock Out Revers To Stock In Successfully","Stock In",JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
	txtstockoutid.setText("");
	txtqtyout.setText("");
	cbostockid.setSelectedIndex(0);
		
	}
}
