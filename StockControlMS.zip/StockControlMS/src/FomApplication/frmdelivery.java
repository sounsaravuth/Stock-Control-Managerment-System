package FomApplication;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Database.IDatabase;
import net.proteanit.sql.DbUtils;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
//import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
//import java.util.Date;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;

public class frmdelivery implements IDatabase {
	stockdb stockdbs = new stockdb();
	 JFrame frameDelivery;
	private JTable table;
	private JTextField txtdid;
	private JTextField txtdn;
	private JTextField txtsearchrecord;
	JDateChooser txtdate = new JDateChooser(); 	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String date = sdf.format(txtdate.getDate());
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmdelivery window = new frmdelivery();
					window.frameDelivery.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmdelivery() {
		initialize();
		//Connection Mysql
		stockdbs.DatabaseConnection();
		FetchData();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameDelivery = new JFrame();
		
		frameDelivery.setBounds(100, 100, 1148, 675);
		frameDelivery.setLocationRelativeTo(null);
		frameDelivery.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameDelivery.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 1132, 68);
		frameDelivery.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("DELEVERY");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBounds(445, 11, 235, 46);
		panel.add(lblNewLabel);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(23, 127, 393, 409);
		frameDelivery.getContentPane().add(tabbedPane);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("DELEVERY", null, panel_1, null);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Delivery ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(56, 45, 82, 33);
		panel_1.add(lblNewLabel_1);
		
		txtdid = new JTextField();
		txtdid.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtdid.setBounds(148, 45, 216, 33);
		panel_1.add(txtdid);
		txtdid.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Delivery Number");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(10, 97, 128, 33);
		panel_1.add(lblNewLabel_1_1);
		
		txtdn = new JTextField();
		txtdn.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				char c = e.getKeyChar();
				if(Character.isLetter(c)) {
					txtdn.setEditable(false);
					JOptionPane.showMessageDialog(null, "Invlid Number" , "Validate" , JOptionPane.WARNING_MESSAGE);
				}else {
					txtdn.setEditable(true);
				}
			}
		});
		txtdn.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtdn.setColumns(10);
		txtdn.setBounds(148, 97, 216, 33);
		panel_1.add(txtdn);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Delivery Number");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_1_1_1.setBounds(10, 152, 128, 33);
		panel_1.add(lblNewLabel_1_1_1);
		
		JButton btnNewButton = new JButton("ADD DELEVERY");
		btnNewButton.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_Delivery_30px.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InsertData();
				FetchData();
				ClearData();
			}
		});
		btnNewButton.setBounds(148, 196, 205, 33);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("UPDATE DELEVERY");
		btnNewButton_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_update_30px.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateData();
				FetchData();
				ClearData();
			}
		});
		btnNewButton_1.setBounds(148, 240, 205, 33);
		panel_1.add(btnNewButton_1);
		
		
		txtdate.setBounds(148, 152, 216, 33);
		panel_1.add(txtdate);
		
		JButton btnNewButton_1_1 = new JButton("DELETE");
		btnNewButton_1_1.setIcon(new ImageIcon("D:\\Java Application\\StockControlMS\\Image\\icons8_delete_30px.png"));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteData();
				FetchData();
				ClearData();
			}
		});
		btnNewButton_1_1.setBounds(148, 284, 205, 33);
		panel_1.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("BACK TO MENU");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMain main = new frmMain();
				main.MainFram.setVisible(true);
				frameDelivery.dispose();
			}
		});
		btnNewButton_1_1_1.setBounds(148, 326, 205, 33);
		panel_1.add(btnNewButton_1_1_1);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("SEARCH", null, panel_2, null);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Search Record");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_2.setBounds(128, 79, 141, 24);
		panel_2.add(lblNewLabel_2);
		
		txtsearchrecord = new JTextField();
		txtsearchrecord.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtsearchrecord.setBounds(24, 133, 354, 34);
		panel_2.add(txtsearchrecord);
		txtsearchrecord.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(455, 156, 649, 379);
		frameDelivery.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				//Search Record
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				TableRowSorter<DefaultTableModel> tRowSorter = new TableRowSorter<DefaultTableModel>(model);
				table.setRowSorter(tRowSorter);
				tRowSorter.setRowFilter(RowFilter.regexFilter(txtsearchrecord.getText().trim()));
			}
		});
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel tModel = (DefaultTableModel)table.getModel();
				txtdid.setText(tModel.getValueAt(table.getSelectedRow(),0).toString());
				txtdn.setText(tModel.getValueAt(table.getSelectedRow(),1).toString());
				date = (tModel.getValueAt(table.getSelectedRow(),2).toString());
			}
		});
		table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		table.setShowGrid(false);
		DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
	       renderer.setHorizontalAlignment( SwingConstants.CENTER );
		scrollPane.setViewportView(table);
	}

	@Override
	public void FetchData() {
		// TODO Auto-generated method stub
		try {
			stockdbs.Displaydb("SELECT * FROM tbldelivery");
			table.setModel(DbUtils.resultSetToTableModel(stockdbs.rs));
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE);
		}
		
	}

	@Override
	public void InsertData() {
		String Deliveryid = txtdid.getText();
		String Deliverynumber = txtdn.getText();
		if(Deliveryid.equals("") && Deliverynumber.equals("") ) {
			JOptionPane.showMessageDialog(null, "Please complate information" , "Warinng" , JOptionPane.WARNING_MESSAGE);
			txtdid.requestFocus();
			return;
		}
		
		try {
			stockdbs.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stockcontrolms","root","");
			String Query = "SELECT * FROM tbldelivery WHERE deliveryid='"+txtdid.getText()+"'";
			stockdbs.st = stockdbs.connection.createStatement();
			stockdbs.rs = stockdbs.st.executeQuery(Query);
			if(stockdbs.rs.next() == true) {
				JOptionPane.showMessageDialog(null, "Record Extist !" , "Warinng" , JOptionPane.WARNING_MESSAGE);
				return;
			}else {
				stockdbs.SpecialRecord("INSERT INTO tbldelivery values('"+txtdid.getText()+"', '"+txtdn.getText()+"' , '"+date+"')");
				JOptionPane.showMessageDialog(null, "Record Delivery Save !" , "Record Save" , JOptionPane.INFORMATION_MESSAGE);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE );
		}
		
	}

	@Override
	public void UpdateData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Update Delivery Record ?" ) == 0) {
			try {
				stockdbs.SpecialRecord("update tbldelivery set deliveryno='"+txtdn.getText()+"',deliverydate='"+date+"' where deliveryid='"+txtdid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Delivery update !" , "Record update" , JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE );
			}
		}
	}

	@Override
	public void DeleteData() {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(null, "Do You want To Delete Delivery Record ?" ) == 0) {
			try {
				stockdbs.SpecialRecord("DELETE FROM tbldelivery where deliveryid='"+txtdid.getText()+"'");
				JOptionPane.showMessageDialog(null, "Record Delivery Delete !" , "Record Delete" , JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception e) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, e , "Error" , JOptionPane.ERROR_MESSAGE );
			}
		}
	}

	@Override
	public void ClearData() {
		// TODO Auto-generated method stub
		txtdid.setText("");
		txtdn.setText("");
		
		
		
	}
	public void SearchRecord() {
		
	
		
	}
}
